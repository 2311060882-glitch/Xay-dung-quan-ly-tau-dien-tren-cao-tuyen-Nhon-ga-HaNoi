### 🌲 SƠ ĐỒ CÂY CÁC LUỒNG CHỨC NĂNG (SYSTEM MINDMAP STRUCTURE)

HỆ THỐNG QUẢN LÝ VẬN HÀNH METRO (HANOI METRO SYSTEM)
├── 1. MÀN HÌNH TRANG CHỦ (HOME)
│   ├── 1.1. Ví điện tử & Nạp tiền (Simulated Top-up API)
│   ├── 1.2. Mua vé tàu (Vé lượt / Vé tháng / Vé nhóm gia đình)
│   ├── 1.3. Đăng ký vé ưu tiên (Học sinh/Sinh viên/Người cao tuổi)
│   ├── 1.4. Lộ trình Đa phương thức MaaS (Kết nối Xe buýt / Be / TNGo)
│   ├── 1.5. Cân bằng tải Giờ Vàng (Gamification hoàn tiền lệch giờ cao điểm)
│   └── 1.6. Phản ánh sự cố cộng đồng (Crowdsourced Maintenance)
│
├── 2. NÚT QR TRUNG TÂM (CORE - NÚT NỔI GIỮA BOTTOM BAR)
│   ├── 2.1. Quét / Hiển thị QR vé nhanh qua cổng soát vé
│   ├── 2.2. Pre-boarding QR Check-in (Quét QR tại cửa đợi sân ga ➔ Auto map Toa tàu)
│   └── 2.3. Xem chi tiết vé & Chuyến đi đang kích hoạt
│
├── 3. HỆ THỐNG CẢNH BÁO KHẨN CẤP (PANIC UI & ĐỊNH VỊ TOA TÀU SOS)
│   ├── 3.1. Tự động lấy vị trí toa tàu từ Pre-boarding Check-in (platform_doors)
│   ├── 3.2. Màn hình chọn Toa tàu trực quan (Panic UI 4 Block: Toa 1, 2, 3, 4)
│   └── 3.3. Chọn loại sự cố (Y tế / An ninh / Kỹ thuật) & Bắn alert Real-time
│
├── 4. MÀN HÌNH VÉ CỦA TÔI
│   ├── 4.1. Phân loại vé (Vé của tôi / Vé mua hộ & Vé nhóm)
│   ├── 4.2. Thẻ vé & Sinh link / QR phụ chia sẻ qua Zalo (Dynamic Sub-QR)
│   ├── 4.3. Xem Lịch sử mua vé & Lịch sử các lượt đi (Journeys)
│   └── 4.4. Cập nhật danh sách vé (Trigger Refresh API)
│
├── 5. MÀN HÌNH TÌM GA TÀU & LỘ TRÌNH
│   ├── 5.1. Chọn Tuyến tàu (Cát Linh - Hà Đông / Nhổn - Ga Hà Nội)
│   └── 5.2. Sơ đồ tuyến ga dạng Timeline dọc (Leaflet Radar mô phỏng vị trí tàu)
│
├── 6. MÀN HÌNH CÁ NHÂN (PROFILE KHÁCH HÀNG)
│   ├── 6.1. Thông tin cá nhân & Điểm uy tín phản ánh sự cố
│   ├── 6.2. Phương thức thanh toán & Quản lý Ví
│   ├── 6.3. Quản lý Đăng ký vé ưu tiên (Theo dõi trạng thái duyệt đơn priority_applications)
│   ├── 6.4. Định danh hộ (Quản lý thông tin người thân trong bảng relatives)
│   ├── 6.5. Cài đặt bảo mật (Đổi mật khẩu / Mã hóa CSRF Session)
│   └── 6.6. Đăng xuất / Gỡ định danh thiết bị
│
└── 7. CỔNG QUẢN TRỊ ADMIN (ADMIN PORTAL)
    ├── 7.1. Đăng nhập Quản trị viên (Phân quyền Role ADMIN)
    ├── 7.2. Trực ban Cảnh báo SOS Real-time (Chuông báo khẩn + Nhấp nháy màu đỏ Toa bị sự cố)
    ├── 7.3. Duyệt Hồ sơ Ưu tiên (indexPriority.php: Duyệt/Từ chối minh chứng)
    ├── 7.4. Quét QR Soát vé tại cổng (Check-in / Check-out xác nhận lượt đi)
    ├── 7.5. Điều hành Chuyến tàu (Tạo chuyến, Cập nhật trạng thái RUNNING/COMPLETED)
    ├── 7.6. Báo cáo & Cân bằng tải giờ cao điểm (Biểu đồ phân tích mật độ hành khách)
    └── 7.7. Công tắc Giả lập Luồng khách (Simulation Mode Toggle - Bật/Tắt sinh mock data 10s)

---

### 📝 CHI TIẾT NGHỆP VỤ CÁC PHÂN NHÁNH (DETAILED BUSINESS LOGIC)

#### 1. Màn hình Trang chủ (Home)
* **1.1. Ví điện tử & Nạp tiền:** Quản lý số dư `balance` bảng `wallets`. Nạp tiền giả lập qua API `top-up`.
* **1.2. Mua vé tàu:** Mua vé cá nhân hoặc Vé nhóm gia đình (khởi tạo `master_ticket_id` và `total_scans` tương ứng).
* **1.3. Đăng ký vé ưu tiên:** Tải ảnh minh chứng (thẻ SV, CCCD), ghi dữ liệu vào `priority_applications` với trạng thái `PENDING`.
* **1.4. Lộ trình Đa phương thức (MaaS):** Tra cứu ga Metro kết nối chặng cuối với các tuyến xe buýt hoặc điểm xe đạp TNGo.
* **1.5. Gamification Cân bằng tải:** Quét vé ngoài khung $07:15 - 08:45$ được hoàn $20\%$ tiền vé vào ví.
* **1.6. Phản ánh sự cố:** Gửi báo cáo hư hỏng tại ga để nhận điểm uy tín `reputation_points`.

#### 2. QR Trung tâm & SOS (Panic UI)
* **2.1. Active QR:** Mã hóa UUID đính kèm thông tin hạn dùng để quẹt qua rào chắn.
* **2.2. Pre-boarding QR Check-in:** Quét QR dán ở Cửa đợi (bảng `platform_doors`) để hệ thống ngầm lưu toa tàu tương ứng (`target_carriage_number`).
* **2.3. SOS Alerting:** Chọn sự cố (Y tế/An ninh/Kỹ thuật) ➔ Bắn API `sos/alert.php` kích hoạt chuông và đèn cảnh báo đỏ trên màn hình Trực ban Admin.

#### 3. Màn hình Vé & Vé Nhóm Gia Đình
* **3.1. Master & Sub-QR:** Mua vé nhóm sinh $1$ Master Ticket. Bấm "Chia sẻ qua Zalo" sinh `share_token` để người đi cùng nhận Sub-QR tự quẹt qua cổng từ.
* **3.2. Quản lý Journeys:** Thống kê lịch sử các lượt quét vào/ra ga (`CHECK_IN` / `CHECK_OUT`).

#### 4. Cổng Quản trị Admin
* **4.1. Trực ban SOS Real-time:** Tiếp nhận tín hiệu khẩn cấp, hiển thị chính xác Ga, Chuyến tàu và Toa tàu gặp sự cố.
* **4.2. Duyệt Đăng ký Ưu tiên:** Xem danh sách đơn `priority_applications`, duyệt ảnh minh chứng qua `indexPriority.php`.
* **4.3. Simulation Mode Worker:** Gạt công tắc giả lập ➔ Frontend chạy `setInterval(10s)` gọi API `simulation/traffic.php` chèn 5-10 lượt quét vé ngẫu nhiên để biểu đồ báo cáo nẩy số real-time.