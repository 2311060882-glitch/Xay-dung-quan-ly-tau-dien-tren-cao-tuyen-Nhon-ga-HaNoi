

## 1. TỔNG QUAN KIẾN TRÚC HỆ THỐNG

Hệ thống được phát triển trên nền tảng **PHP kết hợp MySQL/MariaDB**, tuân thủ kiến trúc phân tầng (Layered Architecture) xử lý dữ liệu theo chuẩn RESTful API với các đặc điểm cốt lõi:

```
[ Frontend / Gate Scanner ]
         │
         ▼
[ Router (.htaccess / router.php) ][cite: 10]
         │
         ▼
[ Helper & Middleware Layer ]
(Auth, CSRF, Idempotency, Scan, Request/Response, Validation)[cite: 17, 18, 20, 21, 23, 24, 25]
         │
         ▼
[ API Controllers ]
(Admin API & User API)[cite: 32, 33, 34, 35, 36, 37, 49, 50, 52, 55, 56, 57, 58, 59]
         │
         ▼
[ Database Schema - 8 Bảng Cốt Lõi + 2 Bảng Mở Rộng ][cite: 14, 19]

```

* **Mô hình Cơ sở Dữ liệu (8 + 2 Bảng):**
* **8 Bảng cốt lõi:** `users`, `lines`, `stations`, `ticket_types`, `tickets`, `trips`, `journeys`, `wallet_transactions`.


* **2 Bảng mở rộng (Nghiệp vụ ưu tiên):** `relatives` (người thân) và `priority_applications` (hồ sơ ưu tiên).




* **Điểm đột phá nghiệp vụ Metro:** Bảng `journeys` được tách khỏi `trips`. Hành khách mua vé và quẹt qua cổng (Gate) hoàn toàn độc lập với các chuyến tàu cụ thể.



---

## 2. CHI TIẾT 5 LUỒNG NGHIỆP VỤ CỐT LÕI

### 2.1. Luồng Quản lý Tài khoản & Ví điện tử (Wallet & Security)

* **Bảo mật & Phiên làm việc:** Session thiết lập chặt chẽ với `cookie_httponly` và `SameSite=Lax`. Mọi request làm thay đổi dữ liệu (`POST`, `PUT`, `DELETE`, `PATCH`) bắt buộc kiểm tra token chống giả mạo `require_csrf()`.


* **Quyền Quản trị:** `require_admin()` đọc trực tiếp cột `role` từ bảng `users` (`SELECT role FROM users WHERE id=?`) thay vì tin tưởng dữ liệu session cũ.


* **Xử lý nạp tiền & Thanh toán chống đúp (Idempotency):**
* Client bắt buộc truyền header `Idempotency-Key`.


* Mỗi giao dịch nạp tiền (`TOPUP`) hoặc mua vé (`BUY_TICKET`) đều ghi lại `idempotency_key` duy nhất gắn liền với `user_id` trong `wallet_transactions`.


* Sử dụng mệnh đề `FOR UPDATE` khóa dòng giao dịch để ngăn hiện tượng bấm đúp trừ tiền hai lần khi mạng lag.





### 2.2. Luồng Người thân & Xét duyệt Ưu tiên (Priority Pass)

* **Khai báo Người thân (`/relatives`):** Hành khách thêm thông tin con cái, người cao tuổi (`relatives`). Khi xóa dùng cơ chế xóa mềm (`deleted_at = NOW()`) để bảo toàn thông tin trên các vé đã phát hành.


* **Nộp hồ sơ Ưu tiên (`indexPriority.php` - User):** Hành khách chọn bản thân hoặc người thân, gửi lý do (học sinh, sinh viên...). Hệ thống dùng `FOR UPDATE` kiểm tra nếu đang có đơn `PENDING` hoặc `APPROVED` thì không cho nộp trùng.


* **Admin xét duyệt (`indexPriority.php` - Admin):** Admin duyệt (`APPROVED`) hoặc từ chối (`REJECTED` - bắt buộc nhập lý do). Khi đơn được duyệt, tài khoản/người thân đó mới có quyền mua loại "Vé tháng ưu tiên" giá rẻ.



### 2.3. Luồng Mua vé & Cấp phát mã QR (Ticketing)

* **Phân loại vé:**
* **Vé lượt (`SINGLE`):** Bắt buộc chọn `origin_station_id` và `destination_station_id` thuộc cùng một tuyến. Giá vé tính theo chặng.


* **Vé ngày (`DAILY`) & Vé tháng (`MONTHLY`):** Không cố định ga đi/đến (`origin_station_id IS NULL`), đi tự do trên tuyến.




* **Tạo vé & Trừ tiền:** Hệ thống tính giá, kiểm tra số dư ví, trừ tiền và tạo dòng vé mới chứa `qr_code` động cùng thời hạn sử dụng (`valid_from`, `expires_at`) trong một Database Transaction.



### 2.4. Luồng Kiểm soát Ra/Vào Ga (Gate Control System)

Nghiệp vụ cốt lõi tại cửa kiểm soát được tập trung xử lý trong hàm `scan_ticket()`:

```
[ Khách xuất trình QR ] 
         │
         ▼
[ SELECT ... FOR UPDATE trên bảng tickets ] (Chống 2 cổng quẹt cùng lúc)[cite: 25]
         │
         ├─► [ Mẫu quét thử / Validate ]: Kiểm tra tính hợp lệ, trả kết quả, không ghi nhận DB[cite: 25, 53]
         │
         ├─► [ CHECK-IN (Vào ga) ]:
         │    1. Kiểm tra vé ACTIVE, còn hạn, đúng ga đi đã đăng ký (với vé lượt)[cite: 25].
         │    2. Kiểm tra vé chưa có lượt đi nào đang mở (`active_ticket_id IS NULL`)[cite: 25].
         │    3. Thêm 1 dòng vào bảng `journeys` (`checked_in_at = NOW()`, `checked_in_by = staff_id`)[cite: 14, 25].
         │
         └─► [ CHECK-OUT (Ra ga) ]:
              1. Tìm lượt đi đang mở trong `journeys`[cite: 25].
              2. Kiểm tra ga ra khác ga vào, đúng ga đến đã mua (với vé lượt)[cite: 25].
              3. Cập nhật `journeys` (`checked_out_at = NOW()`, `checked_out_by = staff_id`)[cite: 14, 25].
              4. Cập nhật trạng thái vé: Nếu vé `SINGLE` -> đổi sang `USED`. Nếu vé ngày/tháng -> giữ `ACTIVE`[cite: 25].

```

### 2.5. Luồng Vận hành Chuyến tàu & Thống kê Báo cáo

* **Sinh chuyến tự động (`sync_automatic_trips()`):** Tự động tạo các chuyến tàu theo các khung thời gian 15 phút (Slot 900 giây) với tiền tố `AUTO-` và cập nhật trạng thái chuyến từ `SCHEDULED` $\rightarrow$ `RUNNING` $\rightarrow$ `COMPLETED`.


* **Báo cáo Doanh thu (`ticket-sales.php`):** Thống kê tổng số vé bán ra và doanh thu, hỗ trợ gom nhóm (`group_by`) theo Ngày, theo Tuyến hoặc theo Loại vé.


* **Báo cáo Lưu lượng (`traffic.php`):** Thống kê chính xác số lượt khách **VÀO (`entries`)** và số lượt khách **RA (`exits`)** tại từng nhà ga trong khoảng thời gian chỉ định.


* **Nhật ký quét gần nhất (`indexJourneys.php`):** Trả về lịch sử quẹt thẻ vừa diễn ra tại các cổng ga theo thứ tự thời gian mới nhất.



---

## 3. TỔNG HỢP CẤU TRÚC FILE HỆ THỐNG

| Thư mục / File | Phân hệ | Chức năng chính |
| --- | --- | --- |
| **`helpers/api.php`** | Core Helper | Kết nối DB, Exception Handler, SQL wrappers, Data Validators (`id`, `text`, `date`, `choice`), Phân trang.

 |
| **`helpers/auth.php`** | Core Helper | Quản lý Session, `require_login()`, `require_admin()` (kiểm tra role từ DB).

 |
| **`helpers/csrf.php`** | Core Helper | Khởi tạo và xác thực `X-CSRF-Token`.

 |
| **`helpers/idempotency.php`** | Core Helper | Đọc header `Idempotency-Key` và khóa dòng giao dịch ví.

 |
| **`helpers/scan.php`** | Core Helper | Hàm `scan_ticket()` xử lý toàn bộ logic Gate Check-in / Check-out.

 |
| **`helpers/automatic-trips.php`** | Core Helper | Tự động sinh và cập nhật trạng thái các chuyến tàu 15 phút/lần.

 |
| **`api/admin/tickets/`** | Admin Gate | Gồm `check-in.php`, `check-out.php`, `validate-qr.php`, `listTickets.php`, `detailTickets.php`.

 |
| **`api/admin/trips/`** | Admin Operational | Gồm `create.php`, `update.php`, `status.php`, `listTrips.php` quản lý lịch chạy tàu.

 |
| **`api/admin/priority/`** | Admin Approval | Duyệt/Từ chối các đơn đăng ký mua vé tháng ưu tiên.

 |
| **`api/admin/reports/`** | Admin Analytics | Gồm `ticket-sales.php` (doanh thu) và `traffic.php` (lưu lượng vào/ra).

 |
| **`api/admin/stations/` & `lines/**` | Admin Catalog | Quản lý danh mục nhà ga và tuyến tàu.

 |
| **`api/user/relatives/` & `priority/**` | User Profile | Khai báo thông tin người thân và nộp hồ sơ xin ưu tiên.

 |

---

## 4. ĐÁNH GIÁ KỸ THUẬT VÀ ĐIỂM SÁNG ĐỒ ÁN

1. **Tính Thực tế Cao (Domain Accuracy):** Tách biệt hoàn toàn Vé/Lượt đi (`journeys`) với Chuyến tàu (`trips`), phản ảnh đúng 100% nguyên lý vận hành Metro ngoài đời thực.


2. **Bảo toàn Dữ liệu & Chống Concurrency:** Sử dụng triệt để `FOR UPDATE` trong MySQL Transactions để ngăn chặn tuyệt đối các lỗi Race-Condition (quẹt thẻ đúp, thanh toán trùng, chọn thứ tự ga trùng).


3. **Mã nguồn Chuẩn mực:** Bắt lỗi tập trung (`set_exception_handler`), tự động `rollback` khi gặp sự cố, đầu ra JSON đồng nhất, chuẩn hóa mã lỗi HTTP (400, 401, 403, 404, 409, 500).