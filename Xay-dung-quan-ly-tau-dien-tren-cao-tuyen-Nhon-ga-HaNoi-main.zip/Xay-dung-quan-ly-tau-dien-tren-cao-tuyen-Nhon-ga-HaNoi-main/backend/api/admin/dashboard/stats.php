<?php
//File này sẽ đếm tổng số User, tính doanh thu vé bán ra hôm nay, số lượt đi và hồ sơ chờ duyệt
require_once __DIR__ . '/../../../helpers/api.php';

// Chỉ Admin mới được gọi API này
require_admin();

// 1. Tổng hành khách (bỏ qua admin)
$totalUsers = fetch_one_row("SELECT COUNT(id) as count FROM users WHERE role = 'USER' ") ['count'] ?? 0;

// 2. Doanh thu hôm nay (Tính tổng giá vé đã mua trong ngày hiện tại)
$todayRevenueRow = fetch_one_row("
    SELECT SUM(tt.price) as total
    FROM tickets t 
    JOIN ticket_types tt ON t.ticket_type_id = tt.id
    WHERE DATE(t.purchased_at) = CURDATE()
");
$todayRevenue = $todayRevenueRow['total'] ?? 0;

// 3. Lượt đi trong ngày (Đếm số chuyến đi được tạo hôm nay)
// Giả sử bảng journeys có cột id (khóa chính tăng dần theo thời gian)
$todayTrips = fetch_one_row("SELECT COUNT(id) as count FROM trips")['count'] ?? 0; // Tạm dùng trips nếu journeys chưa có timestamp

// 4. Hồ sơ chờ duyệt (Định danh hộ / Ưu tiên)
$pendingProfiles = fetch_one_row("SELECT COUNT(user_id) as count FROM priority_applications WHERE status = 'PENDING'")['count'] ?? 0;

respond(true, 'Thành công', [
    'total_users' => (int)$totalUsers,
    'today_revenue' => (int)$todayRevenue,
    'today_trips' => (int)$todayTrips,
    'pending_profiles' => (int)$pendingProfiles
]);