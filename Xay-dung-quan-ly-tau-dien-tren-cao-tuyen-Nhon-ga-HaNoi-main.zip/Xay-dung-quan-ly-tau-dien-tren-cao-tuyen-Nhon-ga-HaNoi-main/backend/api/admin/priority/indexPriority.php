<?php
// --- CORS HEADER DÀNH CHO POST ---
$origin = $_SERVER['HTTP_ORIGIN'] ?? 'http://localhost:5173';
header("Access-Control-Allow-Origin: {$origin}");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token, x-csrf-token, X-Idempotency-Key, Idempotency-Key, Accept");

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
// ---------------------------------

require_once __DIR__ . '/../../../helpers/api.php';
$adminId = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    [$page, $size, $offset] = pagination();
    
    // Lấy status từ URL, mặc định là PENDING
    $status = isset($_GET['status']) && in_array($_GET['status'], ['PENDING','APPROVED','REJECTED']) ? $_GET['status'] : 'PENDING';
    
    // Đếm tổng số
    $total = (int) fetch_one_row('SELECT COUNT(*) AS total FROM priority_applications WHERE status=?', [$status])['total'];
    
    // Lấy danh sách
    $sql = 'SELECT p.*, u.phone, COALESCE(r.fullname, u.fullname) AS passenger_name 
            FROM priority_applications p 
            JOIN users u ON u.id = p.user_id 
            LEFT JOIN relatives r ON r.id = p.relative_id 
            WHERE p.status = ? 
            ORDER BY p.id DESC LIMIT ? OFFSET ?';
            
    $rows = fetch_all_rows($sql, [$status, $size, $offset]);
    
    respond(true, 'Danh sách hồ sơ.', paged($rows, $total, $page, $size));
}

// Xử lý duyệt/từ chối
require_method('POST');
// require_csrf();

$input = read_json();
$id = id_value($input, 'id');
$status = choice($input, 'status', ['APPROVED','REJECTED']);
$reason = $status === 'REJECTED' ? text_value($input, 'rejection_reason', 1000) : null;

execute_sql("UPDATE priority_applications SET status=?, rejection_reason=?, reviewed_at=NOW(), reviewed_by=? WHERE id=? AND status='PENDING'", [$status, $reason, $adminId, $id]);

if ($conn->affected_rows !== 1) {
    respond(false, 'Hồ sơ không tồn tại hoặc đã được xét duyệt.', null, 409);
}

respond(true, 'Đã xét duyệt hồ sơ.');