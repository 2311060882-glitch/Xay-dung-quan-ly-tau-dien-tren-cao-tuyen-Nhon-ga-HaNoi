<?php
require_once __DIR__ . '/../../../helpers/api.php';
require_method('GET');
require_admin();

try {
    // 1. Kiểm tra cấu trúc các cột thực tế đang có trong bảng users
    $columns = fetch_all_rows("SHOW COLUMNS FROM users");
    $columnNames = array_column($columns, 'Field');

    // 2. Xác định tên cột chứa tiền ví (nếu DB chưa có thì mặc định bằng 0)
    $balanceCol = '0';
    if (in_array('balance', $columnNames)) {
        $balanceCol = 'balance';
    } elseif (in_array('wallet_balance', $columnNames)) {
        $balanceCol = 'wallet_balance';
    } elseif (in_array('wallet', $columnNames)) {
        $balanceCol = 'wallet';
    }

    // 3. Kiểm tra xem có cột 'role' hay không để lọc bớt Admin
    $whereClause = in_array('role', $columnNames) ? "WHERE role = 'USER'" : "";

    // 4. Truy vấn danh sách khách hàng an toàn
    $sql = "SELECT id, fullname, phone, {$balanceCol} AS wallet_balance, created_at 
            FROM users 
            {$whereClause} 
            ORDER BY id DESC";
            
    $items = fetch_all_rows($sql);

    respond(true, 'Lấy danh sách khách hàng thành công.', $items);
} catch (Throwable $e) {
    respond(false, 'Lỗi SQL DB: ' . $e->getMessage(), null, 500);
}