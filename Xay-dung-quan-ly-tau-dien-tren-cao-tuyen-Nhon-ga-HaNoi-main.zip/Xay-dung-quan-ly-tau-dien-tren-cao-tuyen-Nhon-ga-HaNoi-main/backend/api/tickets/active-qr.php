<?php

require_once __DIR__ . '/../../helpers/tickets.php';

require_method('GET');
$userId = require_login();

// Bỏ "LIMIT 1" ở cuối để lấy được tất cả vé đang active của user
$tickets = ticket_rows(
    "t.user_id = ? AND (
        j.id IS NOT NULL
        OR (t.status = 'ACTIVE' AND t.valid_from <= NOW() AND t.expires_at > NOW())
    )",
    [$userId],
    'ORDER BY (j.id IS NOT NULL) DESC, t.purchased_at DESC, t.id DESC'
);

if ($tickets) {
    foreach ($tickets as &$t) {
        unset($t['used_at']);
    }
}

// Lúc này biến trả về sẽ là một mảng chứa nhiều vé
respond(true, $tickets ? 'Lấy danh sách QR vé thành công.' : 'Bạn chưa có vé còn hiệu lực.', $tickets);