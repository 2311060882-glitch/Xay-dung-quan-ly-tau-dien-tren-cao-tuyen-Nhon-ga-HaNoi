<?php
require_once __DIR__ . '/../helpers/response.php';
$host = '127.0.0.1';
$port = 3307; 
$username = 'root';
$password = 'root';
$dbname = 'metro';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($host, $username, $password, $dbname, $port);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    respond(
        false,
        'Lỗi kết nối database.',
        [
            'error_code' => $e->getCode(),
            'error_message' => $e->getMessage()
        ],
        500
    );
}
