<?php
require_once __DIR__ . '/response.php';
function start_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        // 1. Tìm Token trong Header gửi từ Frontend
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (function_exists('getallheaders')) {
            $headers = getallheaders();
            $authHeader = $headers['Authorization'] ?? $authHeader;
        }

        // 2. Nếu có chữ "Bearer <token>", báo cho PHP biết đây là Session ID
        if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
            $token = trim($matches[1]);
            if (!empty($token)) {
                session_id($token);
            }
        }

        // 3. Khởi tạo Session nhưng TẮT HOÀN TOÀN việc dùng Cookie
        session_start([
            'use_cookies' => false, 
            'use_only_cookies' => false,
            'use_strict_mode' => false 
        ]);
    }
}
function require_login(): int
{
    start_session();
    if (empty($_SESSION['user_id'])) {
        respond(false, 'Bạn cần đăng nhập.', null, 401);
    }
    return (int) $_SESSION['user_id'];
}
// Luôn đọc quyền từ DB, không tin role do client gửi hoặc role cũ trong session.
function require_admin(): int
{
    $userId = require_login();
    require_once __DIR__ . '/../config/database.php';
    global $conn;
    $stmt = $conn->prepare('SELECT role FROM users WHERE id=?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if(!$user){
        respond(false, 'Tài khoản không còn tồn tại.', null, 401);
    }
    if($user['role'] !== 'ADMIN'){
        respond(false, 'Chỉ quản trị viên được thực hiện thao tác này.', null, 403);
    }
    return $userId;
}
