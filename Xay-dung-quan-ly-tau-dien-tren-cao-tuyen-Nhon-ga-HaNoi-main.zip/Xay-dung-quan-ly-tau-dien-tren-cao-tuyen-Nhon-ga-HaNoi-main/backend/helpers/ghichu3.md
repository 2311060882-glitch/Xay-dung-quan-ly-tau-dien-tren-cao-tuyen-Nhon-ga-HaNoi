Tiếp tục series "giải phẫu" code, chúng ta sẽ mổ xẻ nhóm các file chịu trách nhiệm làm **Bảo vệ (Security) và Lưới lọc (Validation)** cho hệ thống.

### 1. File `auth.php` - Chốt chặn danh tính (Source 3)

File này đóng vai trò như bảo vệ kiểm tra thẻ nhân viên. Ai không có thẻ hoặc sai cấp bậc sẽ bị đuổi ra ngay.

* **Hàm `start_session()`:**
* Không đơn thuần chỉ là mở Session như PHP cơ bản. Hàm này truyền vào 4 cờ cấu hình cực kỳ nghiêm ngặt.


* `'use_strict_mode' => true`: Bắt buộc PHP tự sinh ra ID phiên mới, không nhận ID do bên ngoài ép vào (chống Session Fixation).


* `'cookie_httponly' => true`: Chặn tuyệt đối mã độc Javascript (XSS) trên trình duyệt không cho đọc trộm Cookie chứa Session ID.


* `'cookie_samesite' => 'Lax'`: Chỉ cho phép gửi Cookie nếu request đến từ cùng một tên miền.




* **Hàm `require_login()`:**
* Nhiệm vụ: Ép buộc phải đăng nhập. Nó gọi `start_session()`, kiểm tra xem trong ví (session) có giấy tờ `$SESSION['user_id']` chưa.


* Nếu trống rỗng, lập tức gọi `respond(..., 401)` (Lỗi Unauthorized - Không có quyền truy cập) và chặn đứng luồng chạy. Nếu có, trả về ID của user đó.




* **Hàm `require_admin()`:**
* Nhiệm vụ: Cấp quyền quản trị. Kỹ thuật rất hay ở đây là: **Không bao giờ tin tưởng quyền (role) lưu trong Session**.


* Giả sử user vừa bị sếp giáng chức xuống làm nhân viên thường cách đây 1 giây. Nếu đọc từ Session cũ, hắn vẫn là Admin. Code ở đây đã móc thẳng vào Database (`SELECT role FROM users WHERE id=?`) bằng ID vừa lấy được để soi quyền thực tế tại đúng thời điểm đó.


* Nếu không phải `'ADMIN'`, lập tức văng lỗi `403 Forbidden` (Biết mày là ai rồi, nhưng mày không đủ tuổi vào đây).





### 2. File `csrf.php` - Dấu mộc chống làm giả (Source 5)

CSRF (Cross-Site Request Forgery) là kỹ thuật hacker dụ người dùng bấm vào một đường link lạ (VD: *nhan-qua-mien-phi.com*), nhưng ngầm kích hoạt lệnh rút tiền từ web của em.

* **Hàm `csrf_token()`:**
* Tạo ra một chuỗi 64 ký tự ngẫu nhiên cực mạnh bằng `bin2hex(random_bytes(32))` và nhét vào Session của người dùng khi họ vừa mở web lên. Token này giống như một con dấu bí mật chỉ Server và Frontend chân chính mới biết.




* **Hàm `require_csrf()`:**
* Mỗi khi Frontend muốn thực hiện lệnh POST/PUT/DELETE (như Đổi mật khẩu, Mua vé), nó bắt buộc phải đính kèm con dấu này lên Header (`HTTP_X_CSRF_TOKEN`).


* Hàm `hash_equals()` được dùng để so sánh con dấu gửi lên với con dấu trong kho (Session). Tại sao không dùng dấu `===`? Vì `hash_equals` giúp chống lại **Timing Attack** (hacker đo thời gian Server so sánh chữ số để đoán ngược ra mật mã).





### 3. File `api.php` - Máy dò mìn CSDL (Source 2)

Các hàm trong này đóng vai trò ép kiểu và làm sạch mọi dữ liệu gửi lên trước khi chạm vào Database.

* **Hàm `fetch_all_rows` và `execute_sql`:**
* Hệ thống này dùng hàm `$conn->execute_query()`. Đây là một tính năng hoàn toàn mới và tuyệt vời của PHP 8.2+ (nó gom chung các bước `prepare`, `bind_param`, `execute` và `get_result` vào đúng 1 dòng code duy nhất). Dấu `?` trong SQL sẽ tự động khớp với mảng `$params`, triệt tiêu hoàn toàn khả năng bị SQL Injection.




* **Hàm `id_value(..., $key)`:**
* Chỉ chuyên dùng để hứng các ID (như mã sinh viên, mã lớp, mã ga tàu).
* Nó dùng RegEx `preg_match('/^[1-9][0-9]*$/')` để đảm bảo ID phải là số dương, không được bắt đầu bằng số 0, không có chữ.


* Sau đó dùng `FILTER_VALIDATE_INT` và ép `< 4294967295` để chặn hacker cố tình gửi một con số to chà bá (như 99999 tỷ) làm sập tràn bộ nhớ RAM (Integer Overflow) của Server.




* **Hàm `text_value(..., $key, $max)`:**
* Lọc các đoạn chữ (như Tên, Ghi chú). Nó gọi `trim()` để cắt khoảng trắng thừa hai đầu.


* Điểm tinh tế: Nó dùng `preg_match_all('/./us', $value)` để đếm độ dài chữ. Nếu em dùng hàm `strlen()` bình thường của PHP, chữ "Ê" (tiếng Việt) có thể bị đếm thành 2-3 ký tự tùy bảng mã. Chữ `us` ở đây giúp đếm chuẩn xác từng ký tự Unicode 100%.




* **Hàm `date_value(..., $time)`:**
* Nó sử dụng class `DateTimeImmutable` cao cấp để kiểm tra xem chuỗi ngày tháng (VD: `2024-02-29`) gửi lên có thực sự là một ngày tồn tại trên lịch hay không, hay là ngày ảo hacker chế ra.





Qua nhóm code này, em sẽ thấy tư duy code chuyên nghiệp luôn mang một sự "đa nghi" tuyệt đối. Mọi dữ liệu khách gửi lên đều bị coi là mã độc cho đến khi nó vượt qua các hàm lưới lọc này.
--------------------------------
Trong hệ thống API này, **Cookie** và **Token** giống như một hệ thống an ninh 2 lớp của ngân hàng. Dù cả hai đều dùng để xác minh danh tính, nhưng chúng có nhiệm vụ và cách hoạt động hoàn toàn khác nhau.

**1. Cookie - "Thẻ căn cước" lưu ở trình duyệt (File `auth.php`)**

Khi người dùng đăng nhập thành công, Server (PHP) sẽ tạo ra một phiên làm việc (Session) và cấp cho người dùng một mã định danh (Session ID). Mã này được nhét vào một **Cookie** và tự động gửi về lưu ở trình duyệt của người dùng. Mỗi lần người dùng bấm sang trang khác, trình duyệt sẽ tự động xì cái Cookie này ra cho Server xem để chứng minh "Tôi đã đăng nhập rồi".

Tuy nhiên, Cookie rất dễ bị đánh cắp nếu không kiểm soát chặt. Đó là lý do trong file `auth.php`, hệ thống phải cài đặt các lớp giáp bảo vệ cực kỳ nghiêm ngặt:

* **`'cookie_httponly' => true`**: Khóa vĩnh viễn không cho mã Javascript trên trình duyệt (của Frontend hoặc của Hacker) đọc được nội dung Cookie này. Kỹ thuật này triệt tiêu hoàn toàn rủi ro bị ăn cắp Cookie qua lỗi XSS.


* **`'cookie_samesite' => 'Lax'`**: Yêu cầu trình duyệt chỉ được phép gửi Cookie này lên Server nếu người dùng đang thao tác trên đúng tên miền của hệ thống. Cấm tuyệt đối việc mang Cookie này đi dùng ở các trang web lạ.


* **`'cookie_secure'`**: Ép buộc Cookie chỉ được truyền đi trên đường truyền mã hóa HTTPS, không cho phép dùng HTTP thường để tránh bị nghe lén giữa chừng.



**2. Token - "Mã OTP" xác nhận giao dịch (File `csrf.php`)**

Trong hệ thống cụ thể này, "Token" đang được sử dụng là **CSRF Token** (không phải JWT Token dùng để đăng nhập).

Được sinh ra trong file `csrf.php`, Token này là một chuỗi ngẫu nhiên dài 64 ký tự (ví dụ: `a1b2c3...`) được tạo bằng hàm `bin2hex(random_bytes(32))` và lưu ngầm trong Session của hệ thống.

**Tại sao phải kiểm soát Token này khắt khe như vậy?**
Vì Cookie có một điểm yếu chí mạng: Nó hoạt động quá tự động!
Giả sử em đã đăng nhập web của trường (đã có Cookie). Sau đó, em vào nhầm một trang web xem phim lậu của Hacker. Trên trang đó có một đoạn code ngầm tự động gọi hàm `POST` gửi yêu cầu xóa tài khoản của em về Server trường. Trình duyệt thấy có gửi request thì *tự động* đính kèm luôn cái Cookie căn cước của em vào. Server trường đọc Cookie thấy hợp lệ nên tiến hành xóa tài khoản. Đây gọi là tấn công **CSRF (Giả mạo yêu cầu chéo trang)**.

Để chống lại điều này, file `csrf.php` ra đời với cơ chế:

* Bất cứ khi nào Frontend gửi các lệnh nhạy cảm (POST, PUT, DELETE), nó bắt buộc phải đọc cái mã Token bí mật kia và gửi kèm vào một Header có tên là `HTTP_X_CSRF_TOKEN`.


* Server sẽ dùng hàm `hash_equals()` so sánh xem Token do Frontend gửi lên có khớp tuyệt đối với Token đang lưu trong kho (Session) hay không.


* Trang web của Hacker dù lừa trình duyệt tự gửi được Cookie, nhưng nó mù tịt không thể biết được mã Token CSRF là gì. Không có Token khớp lệnh, hệ thống lập tức từ chối và báo lỗi 403.



**Tóm lại:** Cookie dùng để chứng minh **BẠN LÀ AI**, còn CSRF Token dùng để chứng minh **YÊU CẦU NÀY DO CHÍNH BẠN TỰ BẤM** (chứ không phải bị ai khác xúi giục ngầm).

Hai khái niệm này phối hợp với nhau tạo ra lớp bảo mật thép cho các hệ thống tài chính/dữ liệu.