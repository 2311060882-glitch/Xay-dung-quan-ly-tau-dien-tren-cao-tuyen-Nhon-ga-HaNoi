Để bảo vệ (defend) thành công đoạn code này, bạn cần nắm rõ "dụng ý" đằng sau các kỹ thuật phòng thủ (defensive programming) và xử lý ngoại lệ được áp dụng. Dưới đây là những điểm "nhỏ nhưng có võ" mà các thầy cô rất hay hỏi xoáy:

**1. Kỹ thuật Validate ID (`id_value`)**

* **Tại sao kiểm tra cả `is_int` và `is_string`?** Khi request bằng JSON, ID có thể là kiểu số nguyên (int). Nhưng khi gửi qua URL (GET) hoặc Form-data, ID mặc định luôn là chuỗi (string). Kiểm tra cả hai để API linh hoạt.
* **Regex `/^[1-9][0-9]*$/`:** Đảm bảo ID là số nguyên dương và **không bắt đầu bằng số 0** (chặn các giá trị như `0`, `0123`).
* **Giới hạn `4294967295`:** Đây là giới hạn lớn nhất của kiểu `INT UNSIGNED` 32-bit trong cơ sở dữ liệu (MySQL). Chặn ở đây giúp tránh lỗi tràn bộ nhớ (Out of Range) khi query CSDL.

**2. Đếm ký tự Unicode (`text_value`)**

* **Regex `/./us`:** Cờ `u` (unicode) và `s` (dotall) là điểm ăn tiền. Hàm `strlen()` thông thường đếm số **byte**, nên một chữ tiếng Việt có dấu (ví dụ "Đ") sẽ bị tính là 2-3 bytes. Biểu thức `/./us` kết hợp `preg_match_all` giúp đếm chính xác số lượng **ký tự thực tế** hiển thị trên màn hình.

**3. Xử lý Ngày tháng (`date_value`)**

* **Chặn Null Byte `strpos($value, chr(0))`:** Ngăn chặn kỹ thuật tấn công Null Byte Injection, nơi hacker chèn ký tự rỗng để lừa trình phân tích cú pháp của server.
* **Dấu `!` trong `'!' . $format`:** Đây là tính năng đặc biệt của `DateTimeImmutable`. Ký tự `!` sẽ reset tất cả các thành phần thời gian (giờ, phút, giây) không được truyền vào về mốc 0 (Unix Epoch), thay vì tự động lấy giờ/phút hiện tại của server.

**4. Kỹ thuật Lọc Động (`ticket_filters`)**

* **Khởi tạo `$where = ['1=1'];`:** Giúp việc nối chuỗi các điều kiện `AND` phía sau dễ dàng hơn mà không cần kiểm tra xem mảng `$where` đã có phần tử nào chưa.
* **Logic khoảng thời gian (`DATE_ADD(?, INTERVAL 1 DAY)`):** Thay vì dùng `<= 23:59:59` (dễ sót microsecond), truy vấn dùng `< ngày_hôm_sau` (INTERVAL 1 DAY) đảm bảo bao phủ trọn vẹn 100% thời gian của ngày cuối cùng.
* **Status ảo (CASE WHEN):** Trạng thái `EXPIRED` không được lưu cứng trong CSDL. Code dùng logic động tính toán ngay trong câu SELECT: Nếu vé `ACTIVE` nhưng đã quá hạn (`expires_at <= NOW()`), nó tự động được coi là `EXPIRED`.

**5. Bảo mật Strict Type (`choice`)**

* **`in_array($value, $allowed, true)`:** Tham số `true` thứ 3 bắt buộc so sánh **đồng bộ cả kiểu dữ liệu** (strict mode). Nếu không có `true`, PHP có thể tự ép kiểu ngầm, dẫn đến các lỗi logic bảo mật.

**6. Xử lý Route URL (`route_id`)**

* **`parse_url(..., PHP_URL_PATH)`:** Bóc tách URL, chỉ lấy phần đường dẫn (path) và tự động vứt bỏ các tham số query (phần sau dấu `?`).
* **Regex `~/([0-9]+)(?:/(?:status))?/?$~`:** Bắt chính xác ID từ các URL dạng `/api/tickets/123` hoặc `/api/tickets/123/status`, bỏ qua dấu `/` thừa ở cuối.
----------------------------------------------------

Dựa trên bộ mã nguồn em cung cấp, đây là một hệ thống Backend API bằng PHP được thiết kế cực kỳ chặt chẽ, chuyên nghiệp và an toàn (sử dụng Transaction, Idempotency key, CSRF protection và cấu trúc rõ ràng).

Thầy sẽ giải thích chi tiết chức năng của từng file, cách code bên trong các hàm, và đặc biệt là mối quan hệ mật thiết giữa `request.php` và `response.php` theo đúng yêu cầu của em.

---

### 1. Mối liên hệ đặc biệt giữa `request.php` và `response.php`

Trong kiến trúc Backend này, **`request.php` (Đầu vào)** và **`response.php` (Đầu ra)** là "cặp bài trùng" kiểm soát toàn bộ cánh cửa giao tiếp giữa Frontend và Backend. Chúng có mối quan hệ phụ thuộc lẫn nhau:

* **`request.php` (Source 18) - "Người gác cổng đầu vào":**
* **Nhiệm vụ 1 (CORS):** Mở cửa cho phép các domain được chỉ định (như `localhost:5173`, `hanoimetro.vn`) gọi API, và chặn các domain lạ.


* **Nhiệm vụ 2 (Hàm `require_method`):** Bắt buộc API phải được gọi bằng đúng phương thức (VD: POST). Nếu sai, nó lập tức gọi hàm `respond()` của `response.php` để đuổi cổ (trả về lỗi 405).


* **Nhiệm vụ 3 (Hàm `read_json`):** Đọc dữ liệu JSON thô (`php://input`) mà Frontend gửi lên. Nếu gửi sai định dạng không phải JSON, nó lại gọi hàm `respond()` trả về lỗi 400 hoặc 415.




* **`response.php` (Source 19) - "Người phát ngôn đầu ra":**
* **Nhiệm vụ:** Đây là nơi **duy nhất** định dạng câu trả lời gửi về Frontend.
* **Hàm `respond()`:** Xây dựng một chuẩn JSON thống nhất với 3 thành phần: `status` (mã HTTP), `message` (thông báo), và `data` (hoặc `errors` nếu thất bại). Đặc biệt, hàm này có lệnh `exit;` ở cuối, nghĩa là khi gọi nó, chương trình PHP sẽ dừng lập tức, ngăn chặn các đoạn code rác chạy tiếp.


* **Hàm `validation_error()`:** Dùng để gom nhóm các lỗi nhập liệu (ví dụ: thiếu ID, sai định dạng chữ) và mượn hàm `respond()` đẩy về Frontend với mã lỗi 400.





**Mối liên hệ:** Bất cứ khi nào `request.php` (hoặc bất kỳ file nào khác) phát hiện dữ liệu đầu vào có "mùi" bất thường, nó không dùng `echo` hay `die()` thông thường, mà sẽ gọi thẳng hàm `respond()` của `response.php` để định dạng lỗi chuẩn JSON trả về.

---

### 2. Giải thích chi tiết các Package / File khác

#### A. File `api.php` (Source 12) - Trái tim CSDL & Chuẩn hóa dữ liệu

File này (dựa vào cấu trúc include, đây chính là file `api.php` được các file khác gọi) là trung tâm kết nối DB và bộ lọc dữ liệu.

* **Hàm `handle_api_exception`:** Bắt mọi lỗi nghiêm trọng (Exception). Nếu web sập, nó tự động Rollback (hủy) CSDL, ghi log ngầm và báo lỗi 500 lịch sự cho user.


* **Hàm Tương tác DB (`fetch_all_rows`, `fetch_one_row`, `execute_sql`):** Bọc (Wrap) lại các lệnh của MySQLi. Nó luôn dùng Prepared Statement (`execute_query`) với biến `$params` để **chống tuyệt đối SQL Injection**.


* **Các hàm "Lưới lọc" (`id_value`, `text_value`, `choice`, `date_value`):** Đây là các hàm siêu quan trọng. Nó nhận dữ liệu thô, ép kiểu (ép thành số `(int)`, cắt khoảng trắng `trim()`), kiểm tra giới hạn độ dài. Nếu sai, lập tức gọi `validation_error` (của `response.php`). Nhờ vậy, DB không bao giờ nhận dữ liệu rác.


* **Hàm `pagination()` và `paged()`:** Tính toán toán học tự động cho phân trang (tính OFFSET dựa trên Page và PageSize).



#### B. Nhóm File Bảo mật (Security & Auth)

* **`auth.php` (Source 13):**
* `start_session()`: Khởi tạo phiên làm việc bảo mật cao (chống đánh cắp Cookie bằng `httponly`, `samesite='Lax'`).


* `require_login()` & `require_admin()`: Kiểm tra xem User đã đăng nhập chưa, và có phải là ADMIN không (truy vấn DB thời gian thực để check quyền, không tin tưởng quyền lưu tạm).




* **`csrf.php` (Source 15):**
* Sinh ra và kiểm tra mã CSRF Token. Bắt buộc Frontend gửi kèm token trong Header `HTTP_X_CSRF_TOKEN`. Kỹ thuật này chống hacker dùng web giả mạo dụ người dùng bấm nút gọi API.




* **`Idempotency` / Xử lý ví (Source 16):**
* Kỹ thuật cao cấp cấp doanh nghiệp. Hàm `request_key` đòi hỏi một khóa duy nhất. Hàm `previous_transaction` dùng `FOR UPDATE` (khóa dòng trong DB) để đảm bảo nếu mạng lác, user bấm nút nạp tiền 2 lần liên tiếp, hệ thống chỉ trừ tiền 1 lần.





#### C. Nhóm File Nghiệp vụ (Services)

* **`scan.php` (Source 20 - Logic Quét mã QR vào/ra ga):**
* Hàm `scan_ticket()` chứa toàn bộ não bộ của hệ thống soát vé.
* Nó khóa vé lại (`FOR UPDATE`) để 2 cổng quét cùng lúc không bị lỗi.


* Kiểm tra logic chặt chẽ: Vé hết hạn chưa? Đã có lượt vào (CHECK_IN) thì mới được ra (CHECK_OUT)? Điểm vào phải khác điểm ra? Vé lượt (SINGLE) phải đúng tuyến?


* Nếu đúng, dùng lệnh SQL để `INSERT` vào bảng `journeys` (hành trình) và cập nhật vé thành `USED`.




* **File xử lý Tàu chạy tự động (Source 14):**
* `sync_automatic_trips`: Tự động tính toán thời gian, cứ mỗi 15 phút (900 giây) sinh ra các chuyến tàu ảo mới. Chuyển trạng thái tàu từ Lên lịch (`SCHEDULED`) sang Đang chạy (`RUNNING`) và Kết thúc (`COMPLETED`).




* **`tickets.php` (Source 21) & `journeys.php` (Source 17):**
* Chứa các câu lệnh SQL JOIN chằng chịt để lấy chi tiết vé tàu (bao gồm ga đi, ga đến, trạng thái hành trình) và lịch sử di chuyển trả về cho Frontend hiển thị.





---

### 3. Luồng hoạt động thực tế (Ví dụ: Chức năng Quét mã QR)

Để em hình dung hệ thống móc nối các file thế nào, hãy xem luồng khi Admin cầm máy quét mã QR của khách (gọi API vào hàm `scan_ticket` trong `scan.php`):

1. **Chạm trán Gác cổng:** Frontend gửi Request. File `request.php` kiểm tra Domain có được phép không (CORS). Sau đó, nó yêu cầu phải là HTTP POST (`require_method('POST')`).


2. **Kiểm tra Thẻ ra vào:** Code gọi `require_admin()` (từ `auth.php`). Hệ thống moi Session ra xem ông nội này có phải Admin không.


3. **Kiểm tra Hàng giả:** Code gọi `require_csrf()` (từ `csrf.php`). Tránh bị hacker làm giả request soát vé.


4. **Mở Gói hàng:** Lấy data bằng `read_json()` (từ `request.php`).


5. **Lọc dữ liệu:** Data lấy ra được ném qua hàm `text_value()` và `id_value()` (của `api.php`) để đảm bảo QR code là chuỗi chuẩn, `station_id` là số nguyên.


6. **Xử lý Giao dịch an toàn:** Gọi `$conn->begin_transaction()` (khóa DB). Moi vé tàu ra bằng `FOR UPDATE`. Kiểm tra logic (như đã nói ở phần C).


7. **Thành công hoặc Thất bại:**
* Nếu lỗi (ví dụ: vé đã dùng): Gọi `reject_transaction()` (của `api.php`), hàm này sẽ Rollback DB và mượn `respond()` đẩy lỗi 400 về.


* Nếu thành công: Lưu DB, `$conn->commit()` và gọi `respond()` (của `response.php`) đẩy mã 200 kèm data báo cửa mở.





Kiến trúc em đang có trong tay là **chuẩn mực của RESTful API hiện đại**, chia để trị rất tuyệt vời!