Dưới đây là giải thích chi tiết toàn bộ các hàm, vai trò và logic xử lý bên trong file `api.php` của bạn. Bạn có thể dùng nội dung này để tự tin trả lời khi bị thầy hỏi xoáy vào từng dòng code!

---

### 1. Nhóm Xử Lý Ngoại Lệ & Trả Lỗi (Exception Handling)

#### `handle_api_exception(Throwable $exception): void`

* **Mục đích:** Bắt và xử lý tập trung tất cả các lỗi crash / Exception hệ thống phát sinh mà không nằm trong khối `try-catch`.


* **Logic dòng code:**
* `global $conn;`: Gọi biến kết nối CSDL từ ngoài vào.


* `$conn->rollback();`: Hủy bỏ ngay lập tức toàn bộ các thao tác CSDL đang làm dở dang (Transaction) để tránh dữ liệu bị sai lệch/rác.


* `error_log((string) $exception);`: Ghi chi tiết vết lỗi (Stack trace) vào file log ẩn trên Server để dev check.


* `respond(false, 'Không thể xử lý yêu cầu...', null, 500);`: Trả về phản hồi lỗi JSON ẩn chi tiết lỗi thật đi (tránh để lộ sơ hở bảo mật cho hacker) và báo mã `500 Internal Server Error`.




* **Dòng 16 (`set_exception_handler`):** Đăng ký hàm này làm "lưới hứng lỗi" mặc định cho toàn bộ file PHP.



#### `reject_transaction(string $message, int $status = 409): void`

* **Mục đích:** Chủ động hủy transaction và trả lỗi nghiệp vụ (Business logic error).


* **Logic:** Rollback CSDL và trả về JSON báo lỗi kèm status code mặc định là `409 Conflict` (hoặc custom status).



---

### 2. Nhóm Tương Tác CSDL (Database Helpers)

#### `fetch_all_rows(string $sql, array $params = []): array`

* **Mục đích:** Thực thi câu lệnh `SELECT` lấy ra **nhiều dòng** dữ liệu.


* **Logic:** Dùng `$conn->execute_query($sql, $params)` (Prepared Statement tự động) để chống SQL Injection, sau đó dùng `fetch_all(MYSQLI_ASSOC)` biến kết quả thành mảng 2 chiều có key là tên cột.



#### `fetch_one_row(string $sql, array $params = []): ?array`

* **Mục đích:** Thực thi `SELECT` chỉ để lấy **1 dòng** duy nhất (hoặc trả về `null` nếu không có).


* **Logic:** Tái sử dụng `fetch_all_rows()`. Nếu mảng rỗng `empty($rows)` trả về `null`, ngược lại lấy ngay dòng đầu tiên `$rows[0]`.



#### `execute_sql(string $sql, array $params = []): void`

* **Mục đích:** Thực thi các câu lệnh thay đổi dữ liệu như `INSERT`, `UPDATE`, `DELETE`.


* **Logic:** Gọi `$conn->execute_query()` chạy lệnh SQL kèm `$params` an toàn.



---

### 3. Nhóm Validate & Làm Sạch Đầu Vào (Input Validation)

#### `id_value(array $input, string $key): int`

* **Mục đích:** Kiểm tra và ép kiểu giá trị ID bắt buộc phải là **số nguyên dương hợp lệ**.


* **Logic 3 tầng bảo vệ:**
1. `!is_int($value) && !is_string($value)`: Chặn các kiểu dữ liệu dị như Mảng (Array), Object, Boolean.


2. `preg_match('/^[1-9][0-9]*$/', (string) $value)`: Bắt buộc chuỗi chỉ chứa ký tự số từ 1-9 ở đầu, chặn số 0 (`id = 0`) và các chuỗi chứa chữ cái.


3. `filter_var(..., FILTER_VALIDATE_INT)` & `> 4294967295`: Đảm bảo giá trị nằm trong ngưỡng giới hạn của kiểu `INT UNSIGNED` 32-bit trong MySQL (chặn tràn số).





#### `text_value(array $input, string $key, int $max = 100): string`

* **Mục đích:** Kiểm tra độ dài văn bản nhập vào.


* **Logic:**
* `trim($value)`: Cắt bỏ khoảng trắng thừa 2 đầu.


* `preg_match_all('/./us', $value)`: Đếm số lượng **ký tự thực tế** (Unicode/UTF-8) thay vì đếm số byte như `strlen()` (tránh lỗi đếm sai chữ tiếng Việt có dấu). Báo lỗi nếu rỗng hoặc vượt quá `$max`.





#### `choice(array $input, string $key, array $allowed): string`

* **Mục đích:** Chặn user truyền giá trị nằm ngoài danh sách cho phép (dùng cho các trường trạng thái, Enum).


* **Logic:** `in_array($value, $allowed, true)` với tham số `true` thứ 3 giúp so sánh **nghiêm ngặt cả kiểu dữ liệu (strict mode)**.



#### `date_value(array $input, string $key, bool $time = false): string`

* **Mục đích:** Kiểm tra ngày tháng / thời gian nhập vào có chuẩn định dạng hay không.


* **Logic:**
* `strpos($value, chr(0)) !== false`: Chặn kỹ thuật tấn công Null Byte Injection.


* `DateTimeImmutable::createFromFormat('!' . $format, $value)`: Dấu `!` giúp reset các giá trị giờ/phút/giây không khai báo về mốc 00:00:00 thay vì lấy giờ hiện tại của server.


* So sánh `$date->format($format) !== $value` để chống trường hợp ngày ma (vd: `2024-02-31` sẽ bị tự nhảy sang Tháng 3).





---

### 4. Nhóm Phân Trang & Lọc Dữ Liệu (Pagination & Filters)

#### `pagination(): array`

* **Mục đích:** Đọc tham số `page` và `per_page` từ URL, tính toán `offset` để phân trang CSDL.


* **Logic:**
* Dùng `max(1, $page)` để ép giá trị nhỏ nhất là 1 (chặn số âm/số 0 gây lỗi SQL).


* Chặn giới hạn tối đa `page <= 1000000` và `per_page <= 100` để chống tấn công ngốn RAM/Database.


* **Công thức tính Offset:** `($page - 1) * $pageSize`.





#### `paged(array $items, int $total, int $page, int $pageSize): array`

* **Mục đích:** Đóng gói mảng danh sách bản ghi kèm theo thông tin phân trang chuẩn để trả về cho Frontend.


* **Logic:** Dùng `ceil($total / $pageSize)` để tính **tổng số trang** (làm tròn lên).



#### `ticket_filters(bool $withStatus = true): array`

* **Mục đích:** Tự động xây dựng câu lệnh SQL `WHERE ...` động dựa trên tham số query truyền trên URL.


* **Logic:**
* Khởi tạo `$where = ['1=1'];`: Mẹo nối chuỗi `AND` cực hay mà không cần check xem mảng rỗng hay không.


* Lọc ngày `to`: Dùng `DATE_ADD(?, INTERVAL 1 DAY)` và so sánh dấu `<` thay vì `<= 23:59:59` để đảm bảo lấy hết sạch dữ liệu đến từng miligiây.


* Validation: Nếu truyền cả `from` và `to` thì `from` phải `<= to`.


* Logic Status ảo (`CASE WHEN`): Tính toán trạng thái `EXPIRED` dựa trên `expires_at <= NOW()` ngay trong lúc query nếu vé đang `ACTIVE`.


* Trả về câu lệnh nối `implode(' AND ', $where)` cùng mảng `$params`.





---

### 5. Nhóm Xử Lý URL (Routing Helper)

#### `route_id(): int`

* **Mục đích:** Trích xuất ID nằm trực tiếp trên đường dẫn URL (vd: RESTful API `/api/tickets/123/status`).


* **Logic:**
* `parse_url(..., PHP_URL_PATH)`: Bóc tách URL chỉ lấy phần path, vứt bỏ query string.


* `preg_match('~/([0-9]+)(?:/(?:status))?/?$~', ...)`: Dùng Regex bắt chuỗi số ID.


* Có fallback hỗ trợ đọc `$_GET['id']` khi mở file trực tiếp để debug/test.