<?php
// 1. Cấu hình CORS & Xử lý Preflight Request (OPTIONS) cho toàn bộ API
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
// Danh sách các Domain được phép truy cập API
$allowed_origins = [
    // --- Môi trường Local Dev ---
    'http://localhost:5173',
    'http://localhost:4173',

    // --- Môi trường Production (Thêm tên miền thật của bạn vào đây) ---
    'https://hanoimetro.vn',
    'https://admin.hanoimetro.vn',
    'https://my-metro-app.vercel.app' 
];

header("Access-Control-Allow-Origin: {$origin}");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token, X-Idempotency-Key, Idempotency-Key");

// Preflight OPTIONS Request direkt behandelen
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 2. Weider mat de bestehende Helper-Funktiounen
require_once __DIR__ . '/response.php';

function require_method(string $method): void
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        header('Allow: ' . $method);
        respond(false, 'Phương thức không được hỗ trợ.', null, 405);
    }
}

function read_json(): array
{
    $contentType = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
    if ($contentType !== 'application/json') {
        respond(false, 'Content-Type phải là application/json.', null, 415);
    }

    $raw = file_get_contents('php://input');
    try {
        $value = json_decode($raw, false, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        respond(false, 'Dữ liệu JSON không hợp lệ.', null, 400);
    }
    if (!is_object($value)) {
        respond(false, 'Dữ liệu gửi lên phải là một JSON object.', null, 400);
    }
    return (array) $value;
}