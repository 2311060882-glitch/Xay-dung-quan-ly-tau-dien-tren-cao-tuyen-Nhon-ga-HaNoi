Về lỗi 401 do bất đồng bộ HTTP/HTTPS và bị chặn Cookie, hướng xử lý tối ưu nhất sẽ phụ thuộc vào việc bạn muốn sửa nhanh để test tiếp hôm nay, hay muốn đập đi xây lại chuẩn chỉ cho lúc public dự án. Dưới đây là 2 hướng:

Hướng 1: Giải pháp hoàn hảo nhất cho Production (Dùng Bearer Token thay cho PHP Session)
Đây là cách tối ưu nhất, chuẩn mô hình RESTful API hiện đại. Vì sau này bạn còn làm app điện thoại, quét mã QR thực tế, các thiết bị di động không hỗ trợ tốt việc lưu Cookie chéo domain.

Thật may là trong file axios.ts của bạn đã có sẵn đoạn code lấy Token từ localStorage và gắn vào Header (Authorization: Bearer ${token}). Bạn chỉ cần sửa phía Backend PHP:

Khi Login (login.php): Thay vì lưu $_SESSION['user_id'] = ..., PHP sẽ tạo ra một chuỗi Token (có thể mã hóa bằng thư viện JWT, hoặc đơn giản là tạo chuỗi ngẫu nhiên rồi lưu vào bảng users trong DB) và trả chuỗi đó về cho Frontend lưu vào localStorage.

Khi Check Đăng nhập (auth.php): Thay vì kiểm tra isset($_SESSION['user_id']), PHP sẽ đọc Header từ Frontend gửi lên để lấy Token, giải mã hoặc tra cứu trong DB xem Token đó của ai.
-------------------------------------------------------------------------------------
Thay vì phải cài thêm thư viện JWT phức tạp hay sửa lại cấu trúc Database, chúng ta sẽ áp dụng kỹ thuật "Session qua Header". Nghĩa là PHP vẫn dùng cơ chế Session quản lý người dùng y như cũ, nhưng thay vì gửi Session ID ngầm qua Cookie (bị HTTPS chặn), ta sẽ biến cái Session ID đó thành Token và tự tay truyền qua Header.   