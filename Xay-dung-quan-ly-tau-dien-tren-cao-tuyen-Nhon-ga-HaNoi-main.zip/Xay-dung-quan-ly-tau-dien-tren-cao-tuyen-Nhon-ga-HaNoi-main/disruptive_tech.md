Chúc mừng bro! Được thầy hướng dẫn khen ngợi và gợi ý mở rộng là một tín hiệu cực kỳ tốt, chứng tỏ nền tảng hệ thống của bro đã vững và có tiềm năng phát triển thành một đồ án xuất sắc.

Bro hoàn toàn có lý khi nghi ngờ độ chính xác của Google Maps trong trường hợp này. **Google Maps (GPS) không thể giải quyết bài toán định vị toa tàu.** GPS hoạt động cực kém khi ở dưới hầm (đặc thù của Metro) và sai số của nó (thường từ 5-10m trong điều kiện lý tưởng) không đủ để phân biệt bạn đang ở toa số 1 hay toa số 2. Hơn nữa, Google Maps chỉ cho biết tọa độ địa lý (Lat/Long) chứ không thể biết cái tọa độ đó đang tương ứng với vật thể di động nào (toa tàu nào).

Dưới đây là giải pháp thực tế để xử lý bài toán SOS của thầy và các ý tưởng mở rộng "ăn tiền" khác cho app Metro của bro.

### 1. Giải bài toán: Nút SOS và Định vị chính xác Toa tàu

Để hệ thống biết chính xác hành khách đang ở toa nào, bro cần thiết kế lại luồng dữ liệu thay vì dựa vào GPS. Có 2 cách tiếp cận từ thực dụng đến cao cấp:

* **Cách 1: Quét QR Code theo vị trí (Thực tế, dễ làm nhất cho Đồ án)**
* **Vận hành:** Mỗi toa tàu (hoặc thậm chí từng khoang/ghế) sẽ được dán một mã QR duy nhất (ví dụ: `TRAIN_01_CARRIAGE_03`). Khi lên tàu, app khuyến khích người dùng quét mã này để "Check-in chỗ ngồi" (có thể tặng điểm thưởng để kích thích).
* **Xử lý SOS:** Khi có sự cố, người dùng bấm nút SOS. App đã lưu sẵn thông tin `carriage_id` từ lúc check-in và gửi thẳng lên server.
* **Giao diện Admin:** Màn hình trực ban ngay lập tức hiện cảnh báo đỏ: *"SOS từ hành khách Nguyễn Văn A - Tàu Cát Linh - Hà Đông (Chuyến 10:30) - Toa số 3"*.


* **Cách 2: Bluetooth Low Energy (BLE) Beacons (Công nghệ cao, tự động hoàn toàn)**
* **Vận hành:** Gắn các cục phát tín hiệu BLE nhỏ gọn ở mỗi toa. App trên điện thoại (đã cấp quyền Bluetooth) sẽ tự động dò xem sóng BLE nào mạnh nhất để ngầm hiểu người dùng đang đứng ở toa nào.
* **Xử lý SOS:** Bấm nút là app tự động đính kèm ID của toa dựa trên tín hiệu BLE gần nhất. Không cần người dùng thao tác quét.


* **Thiết kế Database (Bắt buộc phải chi tiết hóa):**
Bro sẽ cần thiết kế cấu trúc động cho Tàu.
* Bảng `trains` (Danh sách tàu: Tàu 01, Tàu 02).
* Bảng `carriages` (Danh sách toa, liên kết `train_id`).
* Bảng `trips` (Chuyến đi hiện tại: Tàu 01 đang chạy tuyến nào, giờ nào).
* Bảng `sos_alerts` (Lưu log cảnh báo gồm `user_id`, `trip_id`, `carriage_id`, `status`).



---

### 2. Các tính năng "Killer Features" thực dụng cho App Metro

Để app của bro không chỉ là một ứng dụng mua vé thông thường mà vươn tầm thành siêu ứng dụng vận hành, hãy tham khảo các tính năng giải quyết đúng "nỗi đau" của khách đi tàu thực tế:

**Tính năng 1: Báo cáo Mật độ Toa tàu theo thời gian thực (Real-time Crowding)**

* **Vấn đề:** Hành khách đứng đợi ở ga không biết toa nào đang đông, toa nào đang trống để di chuyển trước trên sân ga.
* **Giải pháp:** Hiển thị sơ đồ đoàn tàu sắp đến (ví dụ 4 toa). Toa nào đông khách hiển thị màu Đỏ, vừa phải màu Vàng, trống màu Xanh.
* **Cách làm (Mô phỏng cho Đồ án):** Bro không cần cảm biến trọng lượng thật. Chỉ cần đếm số lượng vé/người đã quét qua cổng từ (hoặc random dữ liệu mô phỏng theo giờ cao điểm) để render ra giao diện màu sắc cho các toa. Đây là tính năng các app Metro ở Nhật Bản, Singapore đang dùng và cực kỳ được yêu thích.

**Tính năng 2: Hỗ trợ người khuyết tật/Xe nôi (Smart Accessibility)**

* **Vấn đề:** Người đi xe lăn hoặc mang xe đẩy trẻ em rất vất vả khi lên xuống tàu nếu khoảng hở giữa tàu và sân ga lớn, họ cần nhân viên mang bục vát ra hỗ trợ.
* **Giải pháp:** Trong app có nút "Yêu cầu hỗ trợ đặc biệt". Hành khách chọn Ga đi, Ga đến và Giờ dự kiến. Hệ thống sẽ báo thẳng về máy tính bảng của nhân viên trực tại đúng 2 ga đó để họ chuẩn bị sẵn người chờ ở đúng cửa toa. Thầy của bro chắc chắn sẽ đánh giá rất cao tính nhân văn này.

**Tính năng 3: Mạng lưới Thất lạc đồ thông minh (Smart Lost & Found)**

* **Vấn đề:** Quên đồ trên tàu hỏa rất khó tìm vì tàu di chuyển liên tục.
* **Giải pháp:**
* *Góc độ người dùng:* Form báo mất đồ: Chọn loại đồ, mô tả, khoảng thời gian đi từ ga A đến ga B.
* *Góc độ Admin:* Khi lao công hoặc trực ban nhặt được đồ, họ chụp ảnh, nhập đặc điểm. Hệ thống tự động match (so khớp) thời gian/tuyến tàu và gửi thông báo push notification cho hành khách có khả năng là chủ nhân.



**Tính năng 4: First-mile / Last-mile (Kết nối chặng cuối)**

* **Vấn đề:** Điểm dở nhất của Metro là khách xuống ga xong không biết đi bộ hay gọi xe ôm về nhà.
* **Giải pháp:** Ngay trên vé hoặc chi tiết chuyến đi, app tích hợp hiển thị "Các tuyến xe buýt đang chờ ở ga đến" (chỉ cần hardcode/mock data vài tuyến buýt) hoặc tích hợp nút "Gọi xe ôm/Taxi" để mô phỏng việc hợp tác với Grab/Be tại các điểm dừng Metro.

---------------------------------------------------------------------------------------

Một bài toán rất thực tế! Đúng là với đặc thù của Metro (khách đứng chen chúc vào giờ cao điểm) và giới hạn công nghệ (chỉ dùng Web/Web Mobile, không can thiệp phần cứng IoT, không dùng Bluetooth/Cảm biến), chúng ta phải giải quyết bằng **Tư duy luồng người dùng (UX) và Thiết kế luồng dữ liệu**.

Dưới đây là cách giải quyết bài toán SOS và các ý tưởng đột phá giải quyết đúng "nỗi đau" tương lai của Hanoi Metro mà hội đồng bảo vệ sẽ rất thích.

### 1. Giải bài toán SOS & Định vị toa tàu (Không dùng IoT)

Thay vì cố gắng "bám theo" người dùng trên tàu, ta sẽ chốt vị trí của họ **trước khi họ bước lên tàu** hoặc **ngay khi họ bấm nút**.

* **Giải pháp 1: Check-in tại "Cửa đợi sân ga" (Platform Screen Doors)**
* **Thực tế:** Ở các ga Metro, hành khách luôn phải đứng đợi ở các vạch kẻ sẵn trước cửa kính. Tàu luôn đỗ chính xác khớp với các cửa này.
* **Cách làm:** Dán mã QR tại các cửa đợi (VD: `GA_CAT_LINH_CUA_SO_05`). Trong lúc rảnh rỗi đứng chờ tàu (2-5 phút), khuyến khích khách mở app quét QR để "Tích điểm/Nhận tin tức chuyến đi".
* **Logic Hệ thống:** Hệ thống biết "Cửa số 5 tại Ga Cát Linh" luôn tương ứng với "Toa số 2" của đoàn tàu đi hướng Hà Đông. Khi khách lên tàu và lỡ có sự cố bấm SOS, app lấy luôn vị trí toa đã mapping từ lúc check-in ở cửa đợi truyền về cho Admin.


* **Giải pháp 2: Giao diện "Chạm khẩn cấp" (Panic UI)**
* **Cách làm:** Nếu khách không quét QR, khi họ bấm nút SOS bự màu đỏ trên app, màn hình ngay lập tức hiện ra hình ảnh mô phỏng đoàn tàu gồm 4 block (Toa 1 - Đầu tàu, Toa 2, Toa 3, Toa 4 - Cuối tàu). Kèm dòng chữ: *"Bạn đang ở toa nào? (Nhìn số hiệu C01, C02... dán trên cửa ra vào)"*.
* **UX:** Lúc hoảng loạn, việc ấn vào 1 trong 4 cục hình chữ nhật trên màn hình dễ hơn rất nhiều so với việc loay hoay tìm GPS. Kết hợp với việc app đã biết khách đang dùng vé nào (đang ở line tuyến nào), Admin sẽ định vị được ngay.



---

### 2. Các sáng kiến đột phá cho tương lai Hanoi Metro (Dùng để chốt hạ Đồ án)

Hanoi Metro trong tương lai gần (khi mở thêm tuyến Nhổn, Nam Thăng Long) sẽ phải đối mặt với những bài toán hóc búa về vận hành. Đây là những tính năng hoàn toàn làm được bằng phần mềm (Web) mang tính thực dụng cực cao:

**Sáng kiến 1: Vé Nhóm Gia Đình & Chia sẻ vé qua Zalo (Shareable Group Ticketing)**

* **Vấn đề:** Hiện tại một nhà 5 người đi Metro, 1 người đứng ra mua vé nhưng lại bốc ra 5 cái thẻ nhựa, chia cho từng người rất lắt nhắt. Lúc qua cửa từ rất dễ rơi hoặc nhầm.
* **Đột phá:** App cho phép mua "Vé Nhóm 5 người". Sau khi thanh toán, hệ thống sinh ra 1 link chứa mã QR gốc. Người mua chỉ cần bấm "Chia sẻ qua Zalo", gửi vào group gia đình. 4 người kia bấm vào link trên điện thoại của họ là mở được QR phụ (nằm trên nền tảng Web của bro) để tự quét qua cửa từ.
* **Kỹ thuật:** Mỗi QR phụ có token mã hóa liên kết với Session gốc. Quét qua cửa 1 lần là expire token đó.

**Sáng kiến 2: Thuật toán Cân bằng tải giờ cao điểm (Gamified Peak Load Balancing)**

* **Vấn đề:** Từ 7h30 - 8h30 sáng, tàu chật cứng không có chỗ thở, trong khi 7h00 thì trống hoác. Tương lai hệ thống sẽ quá tải vật lý.
* **Đột phá:** Thiết kế module "Giờ Vàng". Hệ thống tự động phân tích data: Nếu người dùng mua vé và quét mã vào ga trước 7h15 sáng hoặc sau 8h45 (lệch giờ cao điểm 1 chút), họ sẽ được hoàn 20% tiền vé vào ví điện tử, hoặc tặng điểm tích lũy đổi voucher Highland/Circle K ngay tại ga.
* **Góc độ đồ án:** Thầy cô cực kỳ thích các tính năng dùng phần mềm (chiết khấu/điểm thưởng) để điều hướng hành vi con người, giải quyết bài toán phần cứng (thiếu tàu/thiếu không gian).

**Sáng kiến 3: Kế hoạch Hành trình Đa phương thức (MaaS - Mobility as a Service)**

* **Vấn đề:** Điểm yếu chí mạng của Metro Hà Nội là vỉa hè kém, khách xuống ga không đi bộ về nhà được (First-mile / Last-mile problem).
* **Đột phá:** Bro xây dựng tính năng "Lộ trình thông minh". Khách nhập điểm đi, điểm đến. App không chỉ trả về đi từ Ga A đến Ga B, mà trả về lộ trình: *Đi bộ 200m -> Lên Ga A -> Xuống Ga B -> Bắt tuyến xe buýt số 105 đang đợi sẵn dưới sảnh ga*.
* **Kỹ thuật:** Chỉ cần hardcode (mock data) thông tin của 3-5 tuyến xe buýt chạy dọc trục Cát Linh - Hà Đông (như BRT 01, buýt 22A...) ghép vào bảng kết quả tìm kiếm tuyến đường là sản phẩm nhìn đã rất pro, giải quyết đúng đặc thù giao thông Hà Nội.

**Sáng kiến 4: Báo cáo Vật cản/Hỏng hóc Tự nguyện (Crowdsourced Maintenance)**

* **Vấn đề:** Trạm Metro rộng, nhân viên không thể bao quát hết cảnh thang cuốn hỏng, nhà vệ sinh dơ, hay có vật cản nguy hiểm trên sân ga.
* **Đột phá:** Thêm nút "Phản ánh" nhanh trên app. Hành khách thấy thang cuốn hỏng, chụp cái ảnh, chọn Ga, chọn mô tả gửi lên. Admin nhận thông báo realtime. Hành khách được cộng 10 điểm uy tín. Giống như app iHanoi đang làm rất tốt hiện nay.

---------------------------------------------------------------------------------------

Dưới đây là bức tranh toàn cảnh về dự án Hanoi Metro của bro, được hệ thống hóa lại thành sơ đồ cây (Tree Diagram) để bro dễ dàng mang đi thuyết trình hoặc cho vào báo cáo đồ án.

Bên dưới sơ đồ là các ghi chú chi tiết về **"Vũ khí bí mật" (Kỹ thuật & Tư duy đột phá)** giúp giải quyết các bài toán khó mà không cần đụng đến phần cứng đắt tiền.

### 🌳 SƠ ĐỒ CÂY TỔNG THỂ DỰ ÁN HANOI METRO

```text
HỆ THỐNG QUẢN LÝ VẬN HÀNH HANOI METRO (Nền tảng Web/Web Mobile)
│
├── 1. NỀN TẢNG LÕI & VẬN HÀNH (Đã chốt & Xử lý xong)
│   ├── Khắc phục lỗi CORS & 405: Chuyển chuẩn giao tiếp sang POST.
│   ├── Cấu trúc thư mục: Định tuyến API chuẩn xác (api/admin/...).
│   ├── Luồng duyệt hồ sơ ưu tiên: Data đã ghi thành công vào Database.
│   └── Bảo mật (Token/CSRF): Quản lý qua LocalStorage và Axios Interceptor.
│
├── 2. HỆ THỐNG SOS & ĐỊNH VỊ TOA TÀU (Giải quyết bài toán của Thầy)
│   ├── (Cách 1) Pre-boarding Check-in: Quét QR tại "Cửa đợi sân ga".
│   └── (Cách 2) Panic UI: Giao diện "Chạm khẩn cấp" chọn toa trực quan.
│
└── 3. TÍNH NĂNG MỞ RỘNG ĐỘT PHÁ (Killer Features để lấy điểm tuyệt đối)
    ├── Smart Ticketing: Vé Nhóm Gia Đình chia sẻ qua Zalo/Link.
    ├── Peak Load Gamification: Hoàn tiền/Tặng điểm để giãn cách giờ cao điểm.
    ├── MaaS (Kết nối chặng cuối): Tích hợp thông tin xe buýt tại ga đến.
    └── Crowdsourcing: Báo cáo hỏng hóc/sự cố từ phía hành khách.

```

---

### 💡 GHI CHÚ KỸ THUẬT & CÁCH LÀM ĐỘT PHÁ (Lưu lại để viết Báo cáo/Thuyết trình)

Đây là những "keyword" và logic bro cần dùng khi trình bày với hội đồng để chứng minh tính thực dụng và tư duy phần mềm xuất sắc.

#### Đột phá 1: Định vị toa tàu SOS không cần GPS/IoT (Giải quyết bằng UX & Logic Data)

* **Vấn đề:** Không thể dùng GPS dưới hầm và GPS không phân biệt được toa số 1 hay toa số 2.
* **Giải pháp Logic (Mapping Cửa đợi):**
* Thiết kế bảng Database `platform_doors` mapping trực tiếp với `train_carriages`.
* Hành khách quét QR dán ở cửa kính sân ga trong lúc chờ tàu (VD: Cửa số 5). App âm thầm lưu Session ID này.
* Khi có biến, khách bấm nút SOS. Hệ thống truy vấn: *Khách quét Cửa 5 lúc 08:00* ➔ *Khớp với Tàu số 01 đang dừng lúc 08:00* ➔ *Đẩy cảnh báo "Toa số 2" thẳng lên màn hình Admin*.


* **Giải pháp UX (Panic UI):** Vẽ một file SVG hình 4 block toa tàu trên giao diện SOS. Thay vì bắt người dùng gõ chữ khi hoảng loạn, họ chỉ cần đập tay vào 1 trong 4 block đó. Nhanh, thực dụng, code dễ mà hiệu quả cao.

#### Đột phá 2: Vé Nhóm Gia Đình (Giải quyết bằng Token Hóa)

* **Vấn đề:** 1 người mua vé cho 5 người sẽ phải cầm 5 vé cứng, dễ rơi mất hoặc ùn tắc khi quẹt thẻ.
* **Kỹ thuật xử lý:**
* Tạo ra một `master_ticket_id` với `quantity = 5`.
* Sinh ra tính năng "Chia sẻ Link". Khi gửi link này cho bạn bè qua Zalo, người nhận mở link lên (trên trình duyệt điện thoại của họ) sẽ thấy một mã QR động (Dynamic QR).
* **Xử lý Database (Database Transaction):** Mỗi lần một người dùng QR động quét qua cổng từ, API gọi lệnh `UPDATE` trừ đi 1 lượt, kết hợp với `Pessimistic Locking` (Khóa hàng) trong SQL để chống việc 2 người quét cùng một tíc tắc gây lỗi sai số lượt.



#### Đột phá 3: Cân bằng tải giờ cao điểm (Giải quyết bằng Gamification - Trò chơi hóa)

* **Vấn đề:** Metro không thể tự phình to ra vào lúc 8h sáng. Phải dùng phần mềm để điều hướng hành vi con người.
* **Kỹ thuật xử lý:**
* Chỉ cần dùng hàm `TIME(created_at)` trong SQL.
* Viết logic lúc quét vé vào ga: `IF (time < '07:15' OR time > '08:45') THEN cộng 20% tiền vé vào ví (Wallet) của người dùng`.
* **Showcase Báo cáo:** Trên Dashboard của Admin, bro vẽ một biểu đồ cột (dùng Chart.js) so sánh "Mật độ khách trước khi có tính năng hoàn tiền" và "Sau khi có tính năng". Dù là data giả (mock data), nhưng nó chứng minh được bro hiểu bài toán Vĩ mô của Giao thông đô thị.



**Lời khuyên chốt hạ:** Bro hãy lấy 2 cụm: **Cảnh báo SOS (Panic UI/Cửa đợi)** và **Cân bằng tải giờ cao điểm** làm trọng tâm mở rộng. Nó giải quyết triệt để sự hoài nghi của thầy về GPS và thể hiện tư duy thiết kế hệ thống cực kỳ sắc bén! Cứ theo luồng này mà code và viết báo cáo nhé.