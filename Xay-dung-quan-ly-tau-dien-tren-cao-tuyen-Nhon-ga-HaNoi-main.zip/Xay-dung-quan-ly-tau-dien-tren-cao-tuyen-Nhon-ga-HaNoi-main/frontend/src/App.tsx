import { useState, useEffect, type ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { TrainTrack } from 'lucide-react';

// Admin Pages
import AdminLoginPage from './pages/admin/auth/AdminLoginPage';
import AdminDashboardPage from './pages/admin/dashboard/AdminDashboardPage';
import AdminTripsPage from './pages/admin/trips/AdminTripsPage';
import AdminScanQRPage from './pages/admin/tickets/AdminScanQRPage';
import AdminReportsPage from './pages/admin/report/AdminReportsPage';
import AdminPriorityPage from './pages/admin/users/AdminPriorityPage';
import AdminLayout from './pages/admin/dashboard/AdminLayout';
import AdminTicketsPage from './pages/admin/tickets/AdminTicketsPage';
import AdminUsersPage from './pages/admin/users/AdminUsersPage';

// User Pages
import MobileLayout from './templates/MobileLayout';
import Home from './pages/user/auth/Home';
import Tickets from './pages/user/tickets/TicketsPage';
import Stations from './pages/user/stations/Stations'; 
import QRPage from './pages/user/tickets/ActiveQRPage';
import Profile from './pages/user/auth/ProfilePage';
import Login from './pages/user/auth/Login';
import Register from './pages/user/auth/Register'; 
import RegistrationHistory from './pages/user/registrations/PriorityRegistrationsPage';
import RegistrationFormPage from './pages/user/registrations/RegistrationFormPage';
import WalletPage from './pages/user/auth/WalletPage';
import BuyTicketPage from './pages/user/tickets/BuyTicketPage'; 
import RelativesPage from './pages/user/registrations/RelativesPage';
import JourneyHistoryPage from './pages/user/journey/JourneyHistoryPage';
import StationDetailPage from './pages/user/stations/StationDetailPage';

// --- COMPONENT BẢO VỆ ROUTE USER ---
const ProtectedRoute = ({ children }: { children: ReactNode }) => {
  // Thay đổi: Kiểm tra 'token' thay vì 'csrf_token'
  const isAuth = localStorage.getItem('token'); 
  if (!isAuth) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

// --- COMPONENT BẢO VỆ ROUTE ADMIN ---
const AdminProtectedRoute = ({ children }: { children: ReactNode }) => {
  const userStr = localStorage.getItem('user');
  
  if (!userStr) {
    return <Navigate to="/admin/login" replace />;
  }
  
  let isAdmin = false;
  try {
    const user = JSON.parse(userStr);
    isAdmin = Boolean(user && user.role === 'ADMIN');
  } catch (error) {
    console.error("Lỗi đọc dữ liệu user:", error);
  }

  return isAdmin ? <>{children}</> : <Navigate to="/admin/login" replace />;
};

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-primary flex flex-col items-center justify-center text-white relative">
        <div className="animate-pulse flex flex-col items-center">
          <div className="bg-white p-4 rounded-full mb-4 shadow-lg shadow-blue-500/50">
            <TrainTrack size={48} className="text-primary" />
          </div>
          <h1 className="text-2xl font-black tracking-widest">HANOI METRO</h1>
          <p className="text-sm text-blue-200 mt-2 font-medium">Hành trình xanh - Giao thông sạch</p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* PUBLIC ROUTES */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* USER PROTECTED ROUTES */}
        <Route path="/registration/history" element={<ProtectedRoute><RegistrationHistory /></ProtectedRoute>} />
        <Route path="/registration/new" element={<ProtectedRoute><RegistrationFormPage /></ProtectedRoute>} />
        <Route path="/relatives" element={<ProtectedRoute><RelativesPage /></ProtectedRoute>} />
        <Route path="/journeys" element={<ProtectedRoute><JourneyHistoryPage /></ProtectedRoute>} />
        <Route path="/tickets/buy" element={<ProtectedRoute><BuyTicketPage /></ProtectedRoute>} />
        <Route path="/wallet" element={<ProtectedRoute><WalletPage /></ProtectedRoute>} />
        
        {/* ADMIN ROUTES */}
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route
          path="/admin"
          element={
            <AdminProtectedRoute>
              <AdminLayout />
            </AdminProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<AdminDashboardPage />} />
          <Route path="priority-applications" element={<AdminPriorityPage />} />
          <Route path="trips" element={<AdminTripsPage />} />
          <Route path="scan-qr" element={<AdminScanQRPage />} />
          <Route path="reports" element={<AdminReportsPage />} />
          <Route path="tickets" element={<AdminTicketsPage />} />
          <Route path="users" element={<AdminUsersPage />} />
        </Route>

        {/* CÁC TRANG USER CÓ THANH BOTTOM NAVIGATION */}
        <Route element={<ProtectedRoute><MobileLayout /></ProtectedRoute>}>
          <Route path="/" element={<Home />} />
          <Route path="/tickets" element={<Tickets />} />
          <Route path="/qr" element={<QRPage />} />
          <Route path="/stations" element={<Stations />} />
          <Route path="/stations/detail" element={<StationDetailPage />} />
          <Route path="/profile" element={<Profile />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}