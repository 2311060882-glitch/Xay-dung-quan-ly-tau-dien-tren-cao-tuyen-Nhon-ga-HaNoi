import axiosInstance from '../axios';

export const adminApi = {
  getAllRegistrations: () =>
    axiosInstance.get('/admin/priority/indexPriority.php'),

  updateRegistrationStatus: (id: string | number, status: 'APPROVED' | 'REJECTED', reason?: string) =>
    axiosInstance.post('/admin/priority/indexPriority.php', {
      id,
      status,
      rejection_reason: reason,
    }),

  getDashboardStats: () =>
    axiosInstance.get('/admin/dashboard/stats.php'),

  getSOSAlerts: () =>
    axiosInstance.get('/admin/sos/alerts.php'),

  resolveSOS: (id: number) => {
    return axiosInstance.post('/admin/sos/resolve.php', { id });
  },
};