import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'http://localhost:8000/api', 
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: false 
});

// Interceptors: Tự động đính kèm CSRF Token và Authorization Token vào Header mọi request
axiosInstance.interceptors.request.use((config) => {
    const csrfToken = localStorage.getItem('csrf_token');
    if (csrfToken) config.headers['X-CSRF-Token'] = csrfToken;

    // CHỈ TÌM VÀ GỬI KEY 'token'
    const token = localStorage.getItem('token');
    if (token) config.headers['Authorization'] = `Bearer ${token}`;

    return config;
});

export default axiosInstance;