import axiosInstance from '../axios';

export interface PriorityRegistrationPayload {
    is_for_other: boolean;
    full_name: string;
    dob: string;
    id_card: string;
    phone: string;
    email?: string;
    category: string;
    reason: string;
}

export const registrationApi = {
  submit: (data: PriorityRegistrationPayload) =>
    axiosInstance.post('/priority/indexPriority.php', data),

  getHistory: () =>
    axiosInstance.get('/priority/indexPriority.php'),
};