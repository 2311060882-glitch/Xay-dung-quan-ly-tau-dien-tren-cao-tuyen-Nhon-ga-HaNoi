import axiosInstance from './axios';

export const checkInDoorQR = async (doorCode: string) => {
    const response = await axiosInstance.post('/sos/checkin-door.php', { door_code: doorCode });
    return response.data;
};

// Thêm trip_id vào type
export const sendSOSAlert = async (data: { carriage_number: number; issue_type: string; station_id?: number; trip_id?: number }) => {
    const response = await axiosInstance.post('/sos/alert.php', data);
    return response.data;
};

export const getAdminSOSAlerts = async () => {
    const response = await axiosInstance.get('/admin/sos/alerts.php');
    return response.data;
};