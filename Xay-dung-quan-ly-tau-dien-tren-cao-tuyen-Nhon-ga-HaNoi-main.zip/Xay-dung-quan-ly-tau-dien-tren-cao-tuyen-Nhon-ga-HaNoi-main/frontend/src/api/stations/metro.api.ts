import axiosInstance from '../axios';

export const metroApi = {
  getStations: () => axiosInstance.get('/stations/stationsList.php'),
  getLines: () => axiosInstance.get('/lines/lineList.php'),
};