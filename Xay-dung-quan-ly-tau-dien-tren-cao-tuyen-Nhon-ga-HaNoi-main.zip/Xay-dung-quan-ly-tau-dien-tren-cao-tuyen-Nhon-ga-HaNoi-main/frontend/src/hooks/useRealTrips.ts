import { useState, useEffect } from 'react';
import { type ActiveTrain } from './useMultiTrainSimulation';

// Giả định trung bình 3 phút (180 giây) đi giữa 2 ga.
const SECONDS_PER_STATION = 180; 

interface Trip {
    id: number | string;
    trip_code: string;
    status: string;
    departure_time: string;
    direction: string;
}

interface TripsResponse {
    success: boolean;
    data: Trip[];
}

export function useRealTrips(stationsLength: number) {
    const [trains, setTrains] = useState<ActiveTrain[]>([]);

    useEffect(() => {
        const fetchAndCalculatePositions = async () => {
            try {
                const res = await fetch('/api/admin/trips/listTrips.php');
                const data: TripsResponse = await res.json();
                
                if (data.success) {
                    const now = new Date().getTime();
                    const runningTrips = data.data.filter((t) => t.status === 'RUNNING');
                    
                    const mappedTrains = runningTrips.map((trip) => {
                        const depTime = new Date(trip.departure_time).getTime();
                        const elapsedSeconds = (now - depTime) / 1000;
                        
                        // Nếu tàu chưa chạy hoặc âm thời gian
                        if (elapsedSeconds < 0) return null;

                        const totalStations = stationsLength - 1;
                        let stationsPassed = elapsedSeconds / SECONDS_PER_STATION;
                        
                        // Nếu tàu đã chạy hết tuyến
                        if (stationsPassed > totalStations) stationsPassed = totalStations;

                        // Tính toán theo chiều OUTBOUND (0 -> N) hay INBOUND (N -> 0)
                        const isOutbound = trip.direction === 'OUTBOUND';
                        let currentStationIndex = Math.floor(stationsPassed);
                        let progress = (stationsPassed % 1) * 100;

                        if (!isOutbound) {
                            currentStationIndex = totalStations - Math.floor(stationsPassed) - 1;
                            progress = 100 - progress;
                        }

                        return {
                            id: String(trip.id),
                            code: trip.trip_code,
                            stationIndex: currentStationIndex,
                            progress: progress,
                            speed: 0,
                            direction: isOutbound ? 'forward' : 'backward',
                            status: 'moving',
                            waitTimer: 0
                        };
                    }).filter((train): train is ActiveTrain => train !== null); // Bỏ các chuyến null

                    setTrains(mappedTrains);
                }
            } catch (err) {
                console.error("Lỗi fetch trips", err);
            }
        };

        fetchAndCalculatePositions();
        // Cập nhật vị trí mỗi 3 giây
        const interval = setInterval(fetchAndCalculatePositions, 3000);
        return () => clearInterval(interval);
    }, [stationsLength]);

    return trains;
}