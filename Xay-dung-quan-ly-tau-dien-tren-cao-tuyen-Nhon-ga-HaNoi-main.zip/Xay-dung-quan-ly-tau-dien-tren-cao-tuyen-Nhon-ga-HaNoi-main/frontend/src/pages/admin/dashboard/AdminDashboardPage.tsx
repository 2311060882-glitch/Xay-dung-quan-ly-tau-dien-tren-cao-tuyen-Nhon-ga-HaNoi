import { useEffect, useState } from 'react';
import { Users, Ticket, Wallet, ShieldAlert, TrendingUp, Clock, AlertTriangle } from 'lucide-react';
import { adminApi } from '../../../api/admin/admin.api';
// Nhớ import các hook và component bản đồ bạn đã tạo
import { InteractiveMetroMap } from '../../../components/stations/InteractiveMetroMap';
import { useRealTrips } from '../../../hooks/useRealTrips'; // Đường dẫn tùy cấu trúc thư mục của bạn
import { METRO_LINES } from '../../../data/stationsData';

// 1. Cập nhật Type thêm trip_id và carriage_number
type SOSAlertApiRow = {
  id: number;
  issue_type?: string;
  station_name?: string;
  station_id?: number;
  trip_id?: number;
  carriage_number?: number;
  phone?: string;
  status?: string;
  created_at?: string;
};

export interface SOSAlert {
  id: number;
  type: string;
  location: string;
  passenger_phone: string;
  status: 'PENDING' | 'RESOLVED';
  created_at: string;
}

export default function AdminDashboardPage() {
  const [loading, setLoading] = useState(true);
  const [statsData, setStatsData] = useState({
    total_users: 0,
    today_revenue: 0,
    today_trips: 0,
    pending_profiles: 0,
  });
  const [sosAlerts, setSosAlerts] = useState<SOSAlert[]>([]);
  // Khởi tạo state mặc định là tuyến đầu tiên
  const [selectedLineId, setSelectedLineId] = useState(METRO_LINES[0].id);
  
  // Lấy ra danh sách ga của tuyến đang được chọn
  const currentLine = METRO_LINES.find(line => line.id === selectedLineId) || METRO_LINES[0];
  const stationsData = currentLine.stations;

  // Gọi hook dựa trên số lượng ga của tuyến đã chọn (CHỈ GỌI 1 LẦN Ở ĐÂY)
  const realTrains = useRealTrips(stationsData.length);
  const fetchDashboardData = async () => {
    try {
      const [statsRes, sosRes] = await Promise.all([
        adminApi.getDashboardStats(),
        adminApi.getSOSAlerts(),
      ]);

      if (statsRes.data?.success) {
        setStatsData(statsRes.data.data);
      }

      // Chấp nhận nếu có success=true hoặc status=200
      if (sosRes.data?.success || sosRes.data?.status === 200) {
        setSosAlerts(
          (sosRes.data.data ?? []).map((alert: SOSAlertApiRow) => {
            // 2. Logic xử lý chuỗi vị trí thông minh hơn
            let locationText = 'Không xác định';
            if (alert.trip_id && alert.carriage_number) {
              locationText = `Toa ${alert.carriage_number} - Chuyến ${alert.trip_id}`;
            } else if (alert.station_name || alert.station_id) {
              locationText = alert.station_name ?? `Ga ${alert.station_id}`;
            }

            return {
              id: alert.id,
              type: alert.issue_type === 'MEDICAL' ? 'Y tế' : alert.issue_type === 'SECURITY' ? 'An ninh' : alert.issue_type === 'TECHNICAL' ? 'Kỹ thuật' : 'Khác',
              location: locationText,
              passenger_phone: alert.phone ?? 'Không xác định',
              status: alert.status === 'RESOLVED' ? 'RESOLVED' : 'PENDING',
              created_at: alert.created_at ?? new Date().toISOString(),
            };
          })
        );
      }
    } catch (error) {
      console.error('Lỗi tải dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      await fetchDashboardData();
    };

    loadData();

    const interval = window.setInterval(() => {
      loadData();
    }, 5000);

    return () => window.clearInterval(interval);
  }, []);

  const handleResolveAlert = async (alertId: number) => {
    if (!window.confirm('Bạn xác nhận đã xử lý xong cảnh báo này?')) return;
    
    try {
      const res = await adminApi.resolveSOS(alertId);
      if (res.data?.success || res.data?.status === 200) {
        setSosAlerts((prevAlerts) =>
          prevAlerts.map((alert) =>
            alert.id === alertId ? { ...alert, status: 'RESOLVED' } : alert
          )
        );
      }
    } catch (error) {
      console.error('Lỗi khi tiếp nhận SOS:', error);
      alert('Không thể xử lý cảnh báo lúc này. Vui lòng thử lại!');
    }
  };

  const statsCards = [
    { label: 'Khách hàng', value: statsData.total_users.toString(), icon: Users, accent: 'bg-blue-50 text-blue-600' },
    { label: 'Doanh thu', value: new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 }).format(statsData.today_revenue), icon: Wallet, accent: 'bg-emerald-50 text-emerald-600' },
    { label: 'Lượt đi', value: statsData.today_trips.toString(), icon: Ticket, accent: 'bg-violet-50 text-violet-600' },
    { label: 'Hồ sơ chờ', value: statsData.pending_profiles.toString(), icon: TrendingUp, accent: 'bg-amber-50 text-amber-600' },
  ];

  if (loading && sosAlerts.length === 0) {
    return (
      <div className="flex min-h-50 items-center justify-center text-sm font-medium text-gray-500">
        Đang tải dữ liệu dashboard...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">Tổng quan</p>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard vận hành</h1>
        </div>
        <div className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700">
          <Clock size={14} /> Cập nhật realtime
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        {statsCards.map(({ label, value, icon: Icon, accent }) => (
          <div key={label} className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">{label}</p>
                <p className="mt-2 text-2xl font-bold text-gray-900">{value}</p>
              </div>
              <div className={`rounded-xl p-3 ${accent}`}><Icon size={20} /></div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm min-h-[450px] flex flex-col">
          {/* Header chứa nút Chọn tuyến */}
          <div className="flex items-center justify-between mb-4 border-b pb-3">
            <h3 className="font-bold text-gray-800">Bản đồ Live Tracking</h3>
            <select 
              value={selectedLineId} 
              onChange={(e) => setSelectedLineId(e.target.value)}
              className="p-2 border-2 border-blue-100 rounded-lg text-sm bg-blue-50/50 outline-none font-bold text-blue-700 cursor-pointer hover:bg-blue-100 transition-colors"
            >
              {METRO_LINES.map(line => (
                <option key={line.id} value={line.id}>
                  {line.name}
                </option>
              ))}
            </select>
          </div>

          {/* Bản đồ động */}
          <div className="flex-1 relative">
            <InteractiveMetroMap 
              stations={stationsData} 
              trains={realTrains} 
              onSelectStation={(name) => console.log("Admin click ga:", name)}
            />
          </div>
        </div>

        <div className="rounded-2xl border border-rose-100 bg-white p-6 shadow-sm flex flex-col max-h-[400px]">
          <div className="mb-5 flex items-center justify-between border-b border-gray-100 pb-4">
            <h3 className="flex items-center gap-2 text-base font-bold text-gray-900">
              <ShieldAlert size={20} className="text-rose-600" /> Cảnh báo SOS
            </h3>
            <span className="rounded-full bg-rose-100 px-2.5 py-1 text-xs font-bold text-rose-600 animate-pulse">
              {sosAlerts.filter((alert) => alert.status === 'PENDING').length} Mới
            </span>
          </div>

          <div className="space-y-4 overflow-y-auto pr-2">
            {sosAlerts.length === 0 ? (
              <p className="mt-10 text-center text-sm text-gray-400">Chưa có cảnh báo nào.</p>
            ) : (
              sosAlerts.map((alert) => (
                <div key={alert.id} className={`relative flex gap-3 overflow-hidden rounded-xl border p-3.5 ${alert.status === 'PENDING' ? 'border-rose-200 bg-rose-50 shadow-sm' : 'border-gray-100 bg-gray-50 opacity-60'}`}>
                  {alert.status === 'PENDING' && <div className="absolute bottom-0 left-0 top-0 w-1.5 bg-rose-500" />}
                  <div className={`mt-0.5 rounded-full bg-white p-2 shadow-sm ${alert.status === 'PENDING' ? 'text-rose-500' : 'text-gray-400'}`}>
                    {alert.status === 'PENDING' ? <AlertTriangle size={16} className="animate-pulse" /> : <ShieldAlert size={16} />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <p className={`text-sm font-bold ${alert.status === 'PENDING' ? 'text-rose-800' : 'text-gray-700'}`}>{alert.type}</p>
                      <p className="text-[10px] font-bold text-gray-400">{new Date(alert.created_at).toLocaleTimeString('vi-VN')}</p>
                    </div>
                    <p className="mt-1.5 text-xs font-bold text-gray-800">Vị trí: {alert.location}</p>
                    <p className="mt-0.5 text-xs text-gray-500">Khách: {alert.passenger_phone}</p>
                    {alert.status === 'PENDING' ? (
                      <div className="mt-3 flex gap-2">
                        <button 
                        type="button" 
                        onClick={() => handleResolveAlert(alert.id)} 
                        className="flex-1 rounded bg-rose-600 px-2 py-1.5 text-[10px] font-bold uppercase text-white transition hover:bg-rose-700 cursor-pointer"
                      >
                        Tiếp nhận
                      </button>
                      </div>
                    ) : (
                      <p className="mt-2 flex items-center gap-1 text-xs font-bold text-green-600">✓ Đã xử lý</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}