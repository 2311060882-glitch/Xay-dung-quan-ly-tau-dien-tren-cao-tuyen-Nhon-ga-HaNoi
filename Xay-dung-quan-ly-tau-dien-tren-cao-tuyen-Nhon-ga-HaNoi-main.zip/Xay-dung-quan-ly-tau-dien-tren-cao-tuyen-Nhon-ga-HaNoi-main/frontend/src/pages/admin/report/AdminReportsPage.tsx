import { useEffect, useState } from 'react';
import { adminReportsApi } from '../../../api/admin/admin.reports.api';

interface ReportData {
  label: string;
  tickets_sold: number;
  revenue: number;
}

type ReportGroupBy = 'day' | 'line' | 'ticket_type';

interface ReportFilters {
  group_by: ReportGroupBy;
  from?: string;
  to?: string;
  line_id?: number;
  ticket_type_id?: number;
}

export default function AdminReportsPage() {
  const [reports, setReports] = useState<ReportData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  // States cho tất cả các bộ lọc
  const [groupBy, setGroupBy] = useState<ReportGroupBy>('day');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [lineId, setLineId] = useState('');
  const [ticketTypeId, setTicketTypeId] = useState('');

  useEffect(() => {
    const runFetch = async () => {
      setLoading(true);

      const currentFilter: ReportFilters = { group_by: groupBy };
      if (fromDate) currentFilter.from = fromDate;
      if (toDate) currentFilter.to = toDate;
      if (lineId) currentFilter.line_id = Number(lineId);
      if (ticketTypeId) currentFilter.ticket_type_id = Number(ticketTypeId);

      try {
        const res = await adminReportsApi.getTicketSales(currentFilter);
        setReports(res.data.data?.groups ?? []);
      } catch (err) {
        console.error('Lỗi tải báo cáo:', err);
      } finally {
        setLoading(false);
      }
    };

    void runFetch();
  }, [fromDate, groupBy, lineId, ticketTypeId, toDate, refreshKey]);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Thống kê & Báo cáo doanh thu</h2>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-6 flex flex-wrap gap-4 items-end">
        
        <div>
           <label className="block text-xs font-bold text-gray-600 mb-1">Từ ngày</label>
           <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
             className="border border-gray-200 p-2 rounded-lg text-sm font-medium outline-none focus:border-blue-500"/>
        </div>

        <div>
           <label className="block text-xs font-bold text-gray-600 mb-1">Đến ngày</label>
           <input type="date" value={toDate} onChange={e => setToDate(e.target.value)}
             className="border border-gray-200 p-2 rounded-lg text-sm font-medium outline-none focus:border-blue-500"/>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-600 mb-1">Lọc Tuyến tàu</label>
          <select value={lineId} onChange={e => setLineId(e.target.value)}
            className="border border-gray-200 p-2 rounded-lg text-sm font-medium min-w-35 outline-none focus:border-blue-500">
            <option value="">Tất cả các tuyến</option>
            <option value="1">Cát Linh - Hà Đông</option>
            <option value="2">Nhổn - Ga Hà Nội</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-600 mb-1">Lọc Loại vé</label>
          <select value={ticketTypeId} onChange={e => setTicketTypeId(e.target.value)}
            className="border border-gray-200 p-2 rounded-lg text-sm font-medium min-w-35 outline-none focus:border-blue-500">
            <option value="">Tất cả loại vé</option>
            <option value="1">Vé lượt</option>
            <option value="2">Vé ngày</option>
            <option value="3">Vé tháng</option>
          </select>
        </div>

        <div className="ml-auto flex gap-3">
          <div>
            <label className="block text-xs font-bold text-gray-600 mb-1">Nhóm hiển thị</label>
            <select value={groupBy} onChange={(e) => setGroupBy(e.target.value as ReportGroupBy)}
              className="border border-blue-300 bg-blue-50 p-2 rounded-lg text-sm font-bold text-blue-700 outline-none">
              <option value="day">Theo ngày</option>
              <option value="line">Theo tuyến tàu</option>
              <option value="ticket_type">Theo loại vé</option>
            </select>
          </div>
          
          <button onClick={() => setRefreshKey((key) => key + 1)}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold text-sm hover:bg-blue-700 transition-colors h-10.5 self-end shadow-sm">
            Áp dụng lọc
          </button>
        </div>
      </div>

      {loading ? (
        <p className="text-center text-gray-500 py-8">Đang tính toán số liệu...</p>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100 text-xs font-bold text-gray-500 uppercase">
                <th className="p-4">Tiêu chí phân tích</th>
                <th className="p-4 text-center">Số lượng bán ra</th>
                <th className="p-4 text-right">Tổng doanh thu (VNĐ)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-sm">
              {reports.length === 0 ? (
                <tr>
                  <td colSpan={3} className="p-8 text-center text-gray-400 font-medium">Không có giao dịch nào thỏa mãn bộ lọc.</td>
                </tr>
              ) : (
                reports.map((item, index) => (
                  <tr key={index} className="hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-bold text-gray-800">{item.label}</td>
                    <td className="p-4 text-center font-semibold text-blue-600">{item.tickets_sold} vé</td>
                    <td className="p-4 text-right font-bold text-emerald-600">
                      {Number(item.revenue).toLocaleString('vi-VN')} đ
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}