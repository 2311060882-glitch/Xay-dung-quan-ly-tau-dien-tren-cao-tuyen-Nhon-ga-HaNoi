import { useEffect, useState } from 'react';
import { Info, ArrowLeft, ChevronLeft, ChevronRight, QrCode, ScanLine } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ticketApi } from '../../../api/ticket&wallet/ticket.api';
import { checkInDoorQR } from '../../../api/sos.api';
// Đổi từ Html5QrcodeScanner sang dùng core Html5Qrcode
import { Html5Qrcode } from 'html5-qrcode';

interface ActiveTicket {
  id?: number;
  qr_code?: string;
  ticket_type_name?: string;
  expires_at?: string;
  line_name?: string;
  purchase_price?: number | string;
}

interface ActiveTicketApiResponse {
  success?: boolean;
  data?: ActiveTicket | ActiveTicket[];
}

interface CheckInResponse {
  success: boolean;
  message?: string;
  data?: {
    station_id?: number;
    door_code?: string;
    carriage_number?: number;
  };
}

export default function QRPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [tickets, setTickets] = useState<ActiveTicket[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  
  const [activeTab, setActiveTab] = useState<'SHOW_QR' | 'SCAN_QR'>('SHOW_QR');
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  useEffect(() => {
    ticketApi
      .getActiveQR()
      .then((res: { data?: ActiveTicketApiResponse }) => {
        const data = res.data?.data;
        const ticketArray = Array.isArray(data) ? data : data ? [data] : [];
        setTickets(ticketArray);

        const clickedTicketId = searchParams.get('ticket_id');
        if (clickedTicketId && ticketArray.length > 0) {
          const targetIndex = ticketArray.findIndex(t => String(t.id) === String(clickedTicketId));
          if (targetIndex !== -1) {
            setCurrentIndex(targetIndex);
          }
        }
      })
      .catch(() => setTickets([]))
      .finally(() => setLoading(false));
  }, [searchParams]);

  useEffect(() => {
    let html5QrCode: Html5Qrcode | null = null;

    if (activeTab === 'SCAN_QR') {
      // Đợi một chút để React render xong thẻ div id="reader"
      const initCamera = setTimeout(() => {
        html5QrCode = new Html5Qrcode("reader");

        html5QrCode.start(
          { facingMode: "environment" }, // Ưu tiên dùng camera sau
          {
            fps: 10,
            qrbox: { width: 250, height: 250 }
          },
          (decodedText) => {
            // Khi quét thành công -> Dừng camera ngay lập tức
            if (html5QrCode && html5QrCode.isScanning) {
              html5QrCode.stop().then(() => html5QrCode?.clear()).catch(console.error);
            }
            
            checkInDoorQR(decodedText)
              .then((res: CheckInResponse) => {
                if (res?.success) {
                  setScanResult(decodedText);
                  alert(`Check-in thành công tại mã: ${decodedText}`);
                } else {
                  alert(res?.message ?? 'Mã QR không hợp lệ hoặc lỗi hệ thống.');
                }
              })
              .catch((error: unknown) => {
                console.error('Lỗi check-in vị trí:', error);
                alert('Không thể kết nối đến máy chủ.');
              });
          },
          () => {
            // Bỏ qua các frame không có mã QR
          }
        ).catch((err) => {
          console.error("Không thể khởi động camera:", err);
          setCameraError("Không thể mở camera. Vui lòng kiểm tra quyền truy cập.");
        });
      }, 100);

      return () => {
        clearTimeout(initCamera);
        if (html5QrCode && html5QrCode.isScanning) {
          html5QrCode.stop().then(() => html5QrCode?.clear()).catch(console.error);
        }
      };
    }
  }, [activeTab]);

  const handleNext = () => {
    if (currentIndex < tickets.length - 1) setCurrentIndex(prev => prev + 1);
  };

  const handlePrev = () => {
    if (currentIndex > 0) setCurrentIndex(prev => prev - 1);
  };

  const ticket = tickets[currentIndex];

  return (
    <div className="min-h-screen bg-gray-200 flex justify-center items-center">
      <div className="w-full max-w-md min-h-screen bg-white flex flex-col relative pb-6 shadow-2xl">
        <div className="bg-[#ff5a00] text-white px-4 py-3 flex justify-between items-center shadow-sm z-10 rounded-b-md">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate(-1)} className="p-1 hover:bg-black/10 rounded-full cursor-pointer">
              <ArrowLeft size={18} />
            </button>
            <span className="font-bold text-sm">Tuyến 3.1</span>
          </div>
          <span className="font-bold text-sm">Nhổn - Ga Hà Nội</span>
        </div>

        <div className="flex-1 px-5 pt-6 flex flex-col items-center relative">
          <div className="bg-gray-100 p-1 rounded-xl flex w-full max-w-sm mb-6 shadow-inner">
            <button
              onClick={() => setActiveTab('SHOW_QR')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'SHOW_QR' ? 'bg-primary text-white shadow-md' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <QrCode size={18} />
              Mã vé của tôi
            </button>
            <button
              onClick={() => setActiveTab('SCAN_QR')}
              className={`flex-1 py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'SCAN_QR' ? 'bg-primary text-white shadow-md' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <ScanLine size={18} />
              Quét QR Check-in
            </button>
          </div>

          {activeTab === 'SHOW_QR' && (
            <>
              <div className="flex items-center justify-center gap-6 mb-4 w-full">
                <div className="flex items-center text-primary font-bold text-lg">
                  <span className="text-red-500 text-3xl font-black mr-1 tracking-tighter">M</span> 
                  <div className="flex flex-col leading-none">
                    <span className="text-[10px]">HANOI</span>
                    <span>METRO</span>
                  </div>
                </div>
                <span className="text-blue-800 font-bold text-2xl italic tracking-wider">VISA</span>
              </div>

              {loading ? (
                <div className="py-20 text-gray-400 font-medium">Đang tải mã QR vé...</div>
              ) : tickets.length === 0 || !ticket ? (
                <div className="py-16 text-center w-full">
                  <p className="text-gray-500 font-bold text-base">Không tìm thấy vé đang kích hoạt</p>
                  <button 
                    onClick={() => navigate('/tickets/buy')}
                    className="mt-4 px-5 py-2.5 bg-primary text-white font-bold rounded-xl text-sm shadow-md cursor-pointer"
                  >
                    Mua vé ngay
                  </button>
                </div>
              ) : (() => {
                  const qrValue = ticket.qr_code || `TK${String(ticket.id).padStart(7, '0')}`;
                  const codeStr = ticket.id ? `TK${String(ticket.id).padStart(7, '0')}` : '---';
                  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrValue)}`;

                  return (
                    <div className="w-full flex flex-col items-center">
                      <div className="flex items-center w-full justify-between mb-4">
                        <button onClick={handlePrev} disabled={currentIndex === 0} className={`p-2 rounded-full ${currentIndex === 0 ? 'text-gray-200' : 'text-gray-600 hover:bg-gray-100 cursor-pointer'}`}><ChevronLeft size={28} /></button>
                        <div className="w-56 h-56 bg-white p-3 rounded-xl shadow-md border border-gray-100 flex items-center justify-center"><img src={qrImageUrl} alt="Mã QR vé" className="w-full h-full object-contain" /></div>
                        <button onClick={handleNext} disabled={currentIndex === tickets.length - 1} className={`p-2 rounded-full ${currentIndex === tickets.length - 1 ? 'text-gray-200' : 'text-gray-600 hover:bg-gray-100 cursor-pointer'}`}><ChevronRight size={28} /></button>
                      </div>
                      {tickets.length > 1 && <div className="text-xs font-bold text-primary mb-2">Vé {currentIndex + 1} / {tickets.length}</div>}
                      <p className="text-gray-400 text-xs text-center px-4 mb-6">Áp mã này vào cổng xoay. Không đưa mã cho người khác.</p>
                      <div className="w-full text-sm flex flex-col gap-3.5 mt-2">
                        <div className="text-center font-bold text-base text-gray-800 mb-1">{ticket.ticket_type_name || 'Vé đi tàu'}</div>
                        <div className="flex justify-between items-center"><span className="text-gray-500">Mã vé</span><span className="font-bold text-gray-800">{codeStr}</span></div>
                        <div className="flex justify-between items-center"><span className="text-gray-500">Ngày hết hạn</span><span className="font-bold text-[#ff5a00]">{ticket.expires_at ? new Date(ticket.expires_at).toLocaleDateString('vi-VN') : 'Trong ngày'}</span></div>
                        <div className="flex justify-between items-start"><span className="text-gray-500 w-1/3">Tuyến áp dụng</span><span className="font-medium text-gray-800 text-right w-2/3 leading-snug">{ticket.line_name || 'Tuyến 3.1 Nhổn - Ga Hà Nội'}</span></div>
                      </div>
                    </div>
                  );
                })()}
            </>
          )}

          {activeTab === 'SCAN_QR' && (
            <div className="w-full max-w-sm flex flex-col items-center">
              <div className="flex items-start gap-2 bg-blue-50 p-3 rounded-lg mb-4 text-blue-800 text-xs shadow-sm">
                <Info size={16} className="mt-0.5 shrink-0" />
                <p>Hướng camera quét mã QR dán trên cửa ga hoặc trong toa tàu để định vị khẩn cấp.</p>
              </div>
              
              {/* Thẻ div chứa camera */}
              <div id="reader" className="w-full rounded-2xl overflow-hidden border border-gray-200 shadow-md min-h-[300px] bg-black flex justify-center items-center"></div>
              
              {cameraError && (
                <div className="mt-4 p-3 bg-red-50 text-red-600 text-sm font-medium rounded-lg w-full text-center">
                  {cameraError}
                </div>
              )}

              {scanResult && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 text-green-700 font-bold rounded-lg w-full text-center">
                  Check-in mã cửa: {scanResult}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="px-5 mt-auto flex gap-3 pt-6">
          <button onClick={() => navigate(-1)} className="flex-1 py-3.5 bg-white border border-gray-200 text-gray-600 rounded-xl font-bold shadow-sm hover:bg-gray-50 cursor-pointer">Trở về</button>
          {activeTab === 'SHOW_QR' && (
             <button onClick={() => navigate('/tickets/buy')} className="flex-1 py-3.5 bg-primary text-white rounded-xl font-bold shadow-lg shadow-blue-200 cursor-pointer">Mua thêm vé</button>
          )}
        </div>
      </div>
    </div>
  );
}