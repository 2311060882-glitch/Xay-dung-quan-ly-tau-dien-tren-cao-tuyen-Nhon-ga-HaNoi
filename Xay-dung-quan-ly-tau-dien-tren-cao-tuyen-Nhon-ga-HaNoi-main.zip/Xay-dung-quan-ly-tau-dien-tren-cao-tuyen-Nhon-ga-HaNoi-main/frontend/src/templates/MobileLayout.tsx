// src/templates/MobileLayout.tsx
import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import BottomNav from '../components/BottomNav';
import PanicSOSModal from '../components/ui/PanicSOSModal';

export default function MobileLayout() {
  const [showSOS, setShowSOS] = useState(false);

  return (
    <div className="w-full h-screen bg-gray-100 flex justify-center overflow-hidden">
      <div className="w-full max-w-md bg-white h-full relative flex flex-col shadow-xl">
        
        {/* Phần nội dung của từng trang */}
        <div className="flex-1 overflow-y-auto pb-20">
          <Outlet />
        </div>

        {/* Nút SOS cố định góc phải bên trong khung điện thoại */}
        <button 
          onClick={() => setShowSOS(true)}
          className="absolute right-4 bottom-24 z-40 bg-red-600 text-white font-black w-14 h-14 rounded-full shadow-[0_0_20px_rgba(220,38,38,0.6)] border-4 border-white flex items-center justify-center animate-pulse cursor-pointer hover:scale-110 transition-transform text-2xl"
          title="Báo động khẩn cấp SOS"
        >
          🆘
        </button>

        <PanicSOSModal isOpen={showSOS} onClose={() => setShowSOS(false)} />

        {/* Thanh điều hướng dưới đáy */}
        <BottomNav />
      </div>
    </div>
  );
}