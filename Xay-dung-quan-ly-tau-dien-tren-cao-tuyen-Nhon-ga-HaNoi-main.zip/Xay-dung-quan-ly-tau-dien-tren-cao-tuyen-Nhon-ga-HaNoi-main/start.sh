
echo "🚀 Đang khởi động Backend..."
cd backend || exit
php -S localhost:8000 &
BACKEND_PID=$!

echo "⚛️ Đang khởi động Frontend..."
cd ../frontend || exit
npm run dev

# Bắt sự kiện khi bấm Ctrl+C để tắt luôn cả 2
trap "kill $BACKEND_PID; echo 'Đã tắt cả Frontend và Backend!'" EXIT